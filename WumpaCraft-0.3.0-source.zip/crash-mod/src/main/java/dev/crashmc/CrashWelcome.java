package dev.crashmc;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

final class CrashWelcome {
    private static String key(KeyBinding k){return k.getBoundKeyLocalizedText().getString();}
    private static void line(MinecraftClient mc,String text,Formatting color){mc.player.sendMessage(Text.literal(text).formatted(color),false);}
    static void show(MinecraftClient mc,KeyBinding spin,KeyBinding toggle) {
        line(mc,"━━━━ CRASH · N. SANE MINECRAFT ━━━━",Formatting.GOLD);
        line(mc,key(mc.options.jumpKey)+": salto y doble salto  |  "+key(spin)+": giro y romper hojas",Formatting.YELLOW);
        line(mc,key(CrashExpansion.slideKey)+": deslizar y empujar  |  "+key(CrashExpansion.bazookaKey)+": sacar/guardar bazooka",Formatting.YELLOW);
        line(mc,"Bazooka: mantener clic derecho = mira con zoom; clic izquierdo = disparar",Formatting.AQUA);
        line(mc,"Cada disparo usa 5 Wumpas y explota hasta 27 bloques.",Formatting.GRAY);
        line(mc,"Wumpas: 4–8 por mob; hojas: 8 % de soltar fruta (1: 85 %, 2: 13 %, 3: 2 %).",Formatting.GREEN);
        line(mc,"Con la bazooka guardada, selecciona una Wumpa y mantén clic derecho para comer.",Formatting.GREEN);
        line(mc,"AKU AKU · Reúne 3 máscaras; pulsa "+key(CrashExpansion.akuKey)+" para 20 s de invencibilidad.",Formatting.LIGHT_PURPLE);
        line(mc,"Cada máscara evita una muerte y recupera 4 corazones. Activo: elimina mobs hostiles y pacíficos al tocarlos.",Formatting.GRAY);
        line(mc,"Aku Aku no se craftea: cada 20 enemigos hostiles derrotados sueltan una máscara.",Formatting.LIGHT_PURPLE);
        line(mc,"Hasta 3 máscaras por ciclo. Tras acabar el poder puedes volver a reunirlas.",Formatting.GRAY);
        line(mc,key(mc.options.togglePerspectiveKey)+": cámara  |  "+key(toggle)+": activar/desactivar Crash",Formatting.AQUA);
        line(mc,"mod creado por SoyBlingo",Formatting.GOLD);
        mc.player.sendMessage(Text.literal("VIVA CHILE Y LOS PIPIPUPIS").formatted(Formatting.RED,Formatting.BOLD),false);
        line(mc,"━━━━━━━━━━━━━━━━━━━━━━━━━━━━",Formatting.GOLD);
    }
}
