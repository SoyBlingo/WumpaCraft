package dev.crashmc;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.WrittenBookContentComponent;
import net.minecraft.item.*;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.*;
import net.minecraft.util.*;
public final class CrashGuide extends Screen {
 private static final String TITLE="WumpaCraft: guía";
 private record Page(String title,String art,String body){}
 private static final List<Page> PAGES=List.of(
  new Page("¡Bienvenido a WumpaCraft!","crash","Tu aventura comienza aquí.\n\nGira, salta, nada y explora Minecraft como Crash.\n\nEsta guía guarda todos los controles y secretos. Usa las flechas para pasar página."),
  new Page("Movimiento y combate","crash","Espacio: salto y doble salto.\nR: giro y romper hojas.\nC: deslizar y empujar.\n\nPulsa R durante el deslizamiento para pasar al giro sin esperar.\n\nEn el agua, Crash nada automáticamente."),
  new Page("Fruta Wumpa","wumpa","Los mobs derrotados sueltan 4–8 frutas.\n\nHojas: 8 % de dar fruta.\nSi sale: 85 % una, 13 % dos y 2 % tres.\n\nGiro y bazooka también pueden conseguir fruta de las hojas."),
  new Page("Comida y munición","wumpa","Las frutas van al inventario.\n\nGuarda la bazooka, selecciona una Wumpa y mantén clic derecho para comer.\n\nCada una cura 1 corazón y 1 muslo de hambre.\n\nReserva 5 para cada disparo."),
  new Page("La bazooka","crash","Z: sacar o guardar.\nClic derecho: mira y zoom.\nClic izquierdo: disparar.\n\nCada tiro consume 5 Wumpas. La explosión daña y empuja; rompe hasta 27 bloques y deja sus objetos."),
  new Page("Encuentra a Aku Aku","aku_aku","No se puede craftear.\n\nCada 20 enemigos hostiles derrotados sueltan una máscara. Máximo 3 por ciclo.\n\nRecógela para cargarla. Los animales no cuentan para conseguir máscaras."),
  new Page("Una segunda oportunidad","aku_aku","Con 1, 2 o 3 máscaras, un golpe mortal consume SOLO una.\n\nAku Aku te salva, suena su despedida y recuperas 4 corazones con protección breve.\n\nLas demás máscaras se conservan. No te salva de caer al vacío debajo del mundo, como fuera de las islas del End."),
  new Page("Invencibilidad","aku_aku","Con 3 máscaras pulsa V.\n\nDurante 20 segundos no recibes daño y eliminas al tocar tanto enemigos como mobs pacíficos.\n\nAl acabar, vuelve a reunir máscaras derrotando enemigos."),
  new Page("Tu aventura, tus teclas","crash","F5: cambiar cámara.\nF6: activar/desactivar Crash.\n\nPuedes reasignar las teclas en Opciones > Controles.\n\nmod creado por SoyBlingo\n\nVIVA CHILE Y LOS PIPIPUPIS")
 );
 private int page;private int left,top,w,h;
 public CrashGuide(){super(Text.literal(TITLE));}
 public static boolean isGuide(ItemStack stack){var book=stack.get(DataComponentTypes.WRITTEN_BOOK_CONTENT);return book!=null&&(TITLE.equals(book.title().raw())||"Crash: guía de aventura".equals(book.title().raw()));}
 static void give(ServerPlayerEntity p){
  for(int i=0;i<p.getInventory().size();i++){
   var existing=p.getInventory().getStack(i);
   var name=Text.literal(TITLE).formatted(Formatting.GOLD);
   if(isGuide(existing)&&!name.equals(existing.get(DataComponentTypes.CUSTOM_NAME)))existing.set(DataComponentTypes.CUSTOM_NAME,name);
  }
  if(p.getCommandTags().contains("crashmc_guide_v1"))return;
  for(int i=0;i<p.getInventory().size();i++)if(isGuide(p.getInventory().getStack(i))){p.addCommandTag("crashmc_guide_v1");return;}
  var stack=new ItemStack(Items.WRITTEN_BOOK);List<RawFilteredPair<Text>> pages=new ArrayList<>();
  for(var page:PAGES)pages.add(RawFilteredPair.of(Text.literal(page.title+"\n\n").formatted(Formatting.GOLD).append(Text.literal(page.body).formatted(Formatting.BLACK))));
  stack.set(DataComponentTypes.WRITTEN_BOOK_CONTENT,new WrittenBookContentComponent(RawFilteredPair.of(TITLE),"SoyBlingo",0,pages,true));
  stack.set(DataComponentTypes.CUSTOM_NAME,Text.literal(TITLE).formatted(Formatting.GOLD));
  if(p.getInventory().insertStack(stack))p.addCommandTag("crashmc_guide_v1");
 }
 public static boolean openHeld(){var mc=MinecraftClient.getInstance();if(mc.player==null)return false;if(isGuide(mc.player.getMainHandStack())||isGuide(mc.player.getOffHandStack())){mc.setScreen(new CrashGuide());return true;}return false;}
 @Override protected void init(){w=Math.min(380,width-12);h=Math.min(218,height-12);left=(width-w)/2;top=(height-h)/2;
  addDrawableChild(ButtonWidget.builder(Text.literal("<"),b->{if(page>0)page--;}).dimensions(left+12,top+h-25,35,18).build());
  addDrawableChild(ButtonWidget.builder(Text.literal(">"),b->{if(page<PAGES.size()-1)page++;}).dimensions(left+53,top+h-25,35,18).build());
  addDrawableChild(ButtonWidget.builder(Text.literal("Cerrar"),b->close()).dimensions(left+w-70,top+h-25,58,18).build());
 }
 @Override public void renderBackground(DrawContext ctx,int mouseX,int mouseY,float delta) {}
 @Override public void render(DrawContext ctx,int mouseX,int mouseY,float delta){
  ctx.fill(0,0,width,height,0xC0142028);ctx.fill(left-3,top-3,left+w+3,top+h+3,0xFF6B381E);ctx.fill(left,top,left+w,top+h,0xFFF6E4B8);
  ctx.fill(left+112,top+10,left+114,top+h-32,0xFFD4B577);ctx.fill(left,top,left+w,top+30,0xFFAC4A20);
  var p=PAGES.get(page);ctx.drawText(textRenderer,p.title,left+12,top+11,0xFFFFEEB1,false);
  int size=96;var id=Identifier.of("crashmc",p.art.equals("crash")?"textures/gui/crash_guide.png":"textures/item/"+p.art+".png");int tex=p.art.equals("crash")?800:64;
  ctx.drawTexture(RenderLayer::getGuiTextured,id,left+8,top+51,0f,0f,size,size,tex,tex,tex,tex);
  ctx.drawCenteredTextWithShadow(textRenderer,Text.literal("WumpaCraft"),left+56,top+155,0xFFDA742B);
  int y=top+42;for(var line:textRenderer.wrapLines(Text.literal(p.body),w-139)){ctx.drawText(textRenderer,line,left+124,y,0xFF402B22,false);y+=10;}
  ctx.drawText(textRenderer,(page+1)+" / "+PAGES.size(),left+w/2-12,top+h-19,0xFF785138,false);
  super.render(ctx,mouseX,mouseY,delta);
 }
}
