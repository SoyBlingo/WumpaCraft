package dev.crashmc;
import java.nio.file.*;
import java.util.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.*;
import net.minecraft.entity.*;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.util.math.*;
import net.minecraft.world.GameMode;
/** Opt-in fixture: refuses every world except the dedicated disposable test world. */
final class CrashBalanceVerification {
 static int stage;static boolean ran;static Map<String,Object> results=new LinkedHashMap<>();
 static final Path root=FabricLoader.getInstance().getConfigDir().resolve("crashmc");
 static PigEntity pig;
 static void tick(MinecraftClient mc){
  if(!CrashClient.active()||mc.currentScreen!=null||mc.isPaused()||!mc.getServer().getSaveProperties().getLevelName().equals("Crash QA balance 20261005"))return;
  if(!ran){if(!Files.exists(root.resolve("balance-test.request")))return;try{Files.move(root.resolve("balance-test.request"),root.resolve("balance-test.started"),StandardCopyOption.REPLACE_EXISTING);}catch(Exception e){return;}ran=true;}
  if(stage<0)return;stage++;var server=mc.getServer();var id=mc.player.getUuid();
  if(stage==5)server.execute(()->{
   var p=server.getPlayerManager().getPlayer(id);var w=p.getServerWorld();
   p.changeGameMode(GameMode.SURVIVAL);p.getInventory().clear();p.setHealth(20);CrashAbilities.setMasks(p,0);CrashAbilities.setCounter(p,"kills",0);CrashAbilities.setCounter(p,"awards",0);
   CrashAbilities.equipped=true;p.getInventory().insertStack(new ItemStack(CrashItems.WUMPA,4));results.put("fourCannotFire",!CrashAbilities.fire(p)&&CrashAbilities.count(p,CrashItems.WUMPA)==4);
   p.getInventory().insertStack(new ItemStack(CrashItems.WUMPA,1));float pitch=p.getPitch();p.setPitch(-90);results.put("fiveCanFire",CrashAbilities.fire(p));p.setPitch(pitch);results.put("consumesExactlyFive",CrashAbilities.count(p,CrashItems.WUMPA)==0);CrashAbilities.equipped=false;
   p.setHealth(16);p.getHungerManager().setFoodLevel(14);var fruit=new ItemStack(CrashItems.WUMPA,2);var remaining=CrashItems.WUMPA.finishUsing(fruit,w,p);results.put("foodHealsOneHeart",p.getHealth()==18);results.put("foodRestoresOneHungerIcon",p.getHungerManager().getFoodLevel()==16);results.put("foodConsumesOne",remaining.getCount()==1);
   var away=p.getPos().add(0,10,0);for(int n=0;n<19;n++)CrashAbilities.rewardEnemy(p,away);results.put("noAkuBefore20",CrashAbilities.counter(p,"awards")==0);CrashAbilities.rewardEnemy(p,away);results.put("akuOn20",CrashAbilities.counter(p,"awards")==1&&CrashAbilities.counter(p,"kills")==0);for(int n=0;n<60;n++)CrashAbilities.rewardEnemy(p,away);results.put("capsAtThree",CrashAbilities.counter(p,"awards")==3);
   for(var item:w.getEntitiesByClass(ItemEntity.class,new Box(away,away).expand(3),e->true))item.discard();
   CrashAbilities.setMasks(p,3);
   for(int n=3;n>0;n--){p.timeUntilRegen=0;p.clearStatusEffects();p.setHealth(2);p.damage(w,p.getDamageSources().generic(),100);results.put("rescueWith"+n,p.isAlive()&&p.getHealth()==8&&CrashAbilities.masks==n-1);}
   pig=new PigEntity(EntityType.PIG,w);pig.setAiDisabled(true);pig.setPosition(p.getPos());w.spawnEntity(pig);CrashAbilities.invincible=5;
   p.changeGameMode(GameMode.CREATIVE);
  });
  if(stage==12){results.put("contactKillsPassive",pig!=null&&!pig.isAlive());CrashClient.cooldownTicks=0;CrashExpansion.slideTicks=10;net.minecraft.client.option.KeyBinding.onKeyPressed(net.minecraft.client.util.InputUtil.fromKeyCode(82,0));}
  if(stage==13)results.put("spinInterruptsSlide",CrashClient.spinTicks>0&&CrashExpansion.slideTicks==0);
  if(stage==20){server.execute(()->{if(pig!=null)pig.discard();var p=server.getPlayerManager().getPlayer(id);p.removeCommandTag("crashmc_guide_v1");CrashGuide.give(p);boolean hasGuide=false;for(int i=0;i<p.getInventory().size();i++)hasGuide|=CrashGuide.isGuide(p.getInventory().getStack(i));results.put("guideDelivered",hasGuide);try{Files.writeString(root.resolve("balance-test.json"),new com.google.gson.GsonBuilder().setPrettyPrinting().create().toJson(results));}catch(Exception e){throw new RuntimeException(e);}CrashClient.LOG.info("CRASH_BALANCE_VERIFY {}",results);});stage=-1;mc.execute(()->mc.setScreen(new CrashGuide()));}
 }
}
