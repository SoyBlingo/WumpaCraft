package dev.crashmc;

import com.google.gson.*;
import dev.crashmc.generated.Appearance;
import dev.crashmc.generated.Spin;
import dev.crashmc.generated.HandItems;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ModelTransformationMode;
import net.minecraft.util.Arm;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Local owned-game mesh cache; original NST skeletal animation playback. */
public final class CrashModel {
    private record Joint(String name, int parent, Vector3f pivot) {}
    private record Mesh(int material, float[] vertices, int[] joints, int[] indices, float[] animated) {}
    private static Joint[] skeleton;
    private static Matrix4f[] transforms;
    private static Mesh[] meshes;
    private static Identifier[] textures;
    private static boolean loaded, attempted;
    private static String failure = "sin preparar";
    public static boolean ready() { return loaded; }
    public static String error() { return failure; }

    public static void load() {
        if (attempted) return;
        attempted = true;
        Path root = FabricLoader.getInstance().getConfigDir().resolve(Appearance.CACHE_FOLDER);
        List<Identifier> registered = new ArrayList<>();
        try {
            JsonObject info;
            try (var reader = Files.newBufferedReader(root.resolve("model.json"))) { info = JsonParser.parseReader(reader).getAsJsonObject(); }
            if (info.get("format").getAsInt() != Appearance.MODEL_FORMAT) throw new IOException("Formato de modelo incompatible");
            JsonArray bones = info.getAsJsonArray("joints");
            if (bones.isEmpty() || bones.size() > 512) throw new IOException("Esqueleto inválido");
            skeleton = new Joint[bones.size()]; transforms = new Matrix4f[bones.size()];
            for (int i = 0; i < bones.size(); i++) {
                var b = bones.get(i).getAsJsonObject(); var p = b.getAsJsonArray("pivot"); int parent = b.get("parent").getAsInt();
                if (parent >= i || parent < -1) throw new IOException("Jerarquía inválida");
                skeleton[i] = new Joint(b.get("name").getAsString(), parent, new Vector3f(p.get(0).getAsFloat(), p.get(1).getAsFloat(), p.get(2).getAsFloat()));
                transforms[i] = new Matrix4f();
            }
            var materials = info.getAsJsonArray("materials"); textures = new Identifier[materials.size()];
            if (textures.length < 1 || textures.length > 64) throw new IOException("Materiales inválidos");
            try (var in = new DataInputStream(new BufferedInputStream(Files.newInputStream(root.resolve("model.bin"))))) {
                if (in.readInt() != Appearance.MODEL_MAGIC) throw new IOException("Cabecera de modelo inválida");
                int count = in.readInt(); if (count < 1 || count > 256) throw new IOException("Mallas inválidas"); meshes = new Mesh[count];
                for (int m = 0; m < count; m++) {
                    int material = in.readInt(), n = in.readInt(), ni = in.readInt();
                    if (material < 0 || material >= textures.length || n < 1 || n > 100000 || ni < 3 || ni > 600000 || ni % 3 != 0) throw new IOException("Malla inválida");
                    float[] vertices = new float[n * 16]; int[] joints = new int[n * 8], indices = new int[ni];
                    for (int v = 0; v < n; v++) {
                        for (int k = 0; k < 16; k++) { float f = in.readFloat(); if (!Float.isFinite(f)) throw new IOException("Vértice inválido"); vertices[v*16+k] = f; }
                        for (int k = 0; k < 8; k++) { int j = in.readInt(); if (j < 0 || j >= skeleton.length) throw new IOException("Hueso inválido"); joints[v*8+k] = j; }
                    }
                    for (int k = 0; k < ni; k++) { int j = in.readInt(); if (j < 0 || j >= n) throw new IOException("Índice inválido"); indices[k] = j; }
                    meshes[m] = new Mesh(material, vertices, joints, indices, new float[n * 6]);
                }
                if (in.read() != -1) throw new IOException("Datos sobrantes en modelo");
            }
            for (int i = 0; i < textures.length; i++) {
                String name = materials.get(i).getAsJsonObject().get("texture").getAsString();
                if (!name.matches("[a-z0-9_]+\\.png")) throw new IOException("Ruta de textura inválida");
                try (var stream = Files.newInputStream(root.resolve(name))) {
                    NativeImage image = NativeImage.read(stream);
                    textures[i] = Identifier.of("crashmc", "local_" + i);
                    MinecraftClient.getInstance().getTextureManager().registerTexture(textures[i], new NativeImageBackedTexture(image));
                    registered.add(textures[i]);
                }
            }
            CrashMotion.load(root, skeleton.length);
            loaded = true;
            CrashClient.LOG.info("Crash cache loaded: {} meshes, {} joints", meshes.length, skeleton.length);
        } catch (Exception ex) {
            for (Identifier id : registered) MinecraftClient.getInstance().getTextureManager().destroyTexture(id);
            failure = ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage();
            CrashClient.LOG.error("Crash cache failed; vanilla player remains visible", ex);
        }
    }
    private static void animate(Entity player, float delta) {
        CrashMotion.pose(player, delta, transforms);
        Vector3f position = new Vector3f(), normal = new Vector3f();
        for (Mesh mesh : meshes) {
            for (int v = 0; v < mesh.vertices.length / 16; v++) {
                int base = v*16, out = v*6; Arrays.fill(mesh.animated, out, out+6, 0);
                for (int k = 0; k < Appearance.BONE_INFLUENCES; k++) {
                    float weight = mesh.vertices[base+8+k]; if (weight <= 0) continue;
                    Matrix4f t = transforms[mesh.joints[v*8+k]];
                    position.set(mesh.vertices[base], mesh.vertices[base+1], mesh.vertices[base+2]); t.transformPosition(position);
                    normal.set(mesh.vertices[base+3], mesh.vertices[base+4], mesh.vertices[base+5]); t.transformDirection(normal);
                    mesh.animated[out] += position.x*weight; mesh.animated[out+1] += position.y*weight; mesh.animated[out+2] += position.z*weight;
                    mesh.animated[out+3] += normal.x*weight; mesh.animated[out+4] += normal.y*weight; mesh.animated[out+5] += normal.z*weight;
                }
            }
        }
    }
    public static void render(Entity player, double x, double y, double z, float delta, MatrixStack matrices, VertexConsumerProvider consumers, int light) {
        if (!loaded) return;
        animate(player, delta);
        matrices.push(); matrices.translate(x, y, z);
        float turn = 0;
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-player.getYaw() + turn));
        if (player.isSneaking()) matrices.scale(1, 0.8f, 1);
        var entry = matrices.peek();
        for (Mesh mesh : meshes) {
            var consumer = consumers.getBuffer(RenderLayer.getEntityCutoutNoCull(textures[mesh.material]));
            for (int t = 0; t < mesh.indices.length; t += 3) for (int k = 0; k < 4; k++) {
                int v = mesh.indices[t + Math.min(k, 2)], a = v*6, b = v*16;
                consumer.vertex(entry, mesh.animated[a], mesh.animated[a+1], mesh.animated[a+2])
                    .color(255,255,255,255).texture(mesh.vertices[b+6], mesh.vertices[b+7])
                    .overlay(OverlayTexture.DEFAULT_UV).light(light)
                    .normal(entry, mesh.animated[a+3], mesh.animated[a+4], mesh.animated[a+5]);
            }
        }
        CrashProps.bazooka(player,delta,matrices,consumers,light);
        if (!CrashAbilities.equipped && player instanceof LivingEntity living) {
            boolean left = living.getMainArm() == Arm.LEFT;
            renderHand(living, living.getMainHandStack(), left, matrices, consumers, light);
            renderHand(living, living.getOffHandStack(), !left, matrices, consumers, light);
        }
        matrices.pop();
    }
    private static void renderHand(LivingEntity player, ItemStack stack, boolean left, MatrixStack matrices, VertexConsumerProvider consumers, int light) {
        if (stack.isEmpty()) return;
        String target = left ? HandItems.LEFT_BONE : HandItems.RIGHT_BONE;
        for (int i = 0; i < skeleton.length; i++) if (skeleton[i].name.equals(target)) {
            matrices.push();
            matrices.multiplyPositionMatrix(transforms[i]);
            Vector3f pivot = skeleton[i].pivot;
            matrices.translate(pivot.x, pivot.y, pivot.z);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180));
            matrices.scale((float)HandItems.SCALE, (float)HandItems.SCALE, (float)HandItems.SCALE);
            MinecraftClient.getInstance().getItemRenderer().renderItem(player, stack,
                left ? ModelTransformationMode.THIRD_PERSON_LEFT_HAND : ModelTransformationMode.THIRD_PERSON_RIGHT_HAND,
                left, matrices, consumers, player.getWorld(), light, OverlayTexture.DEFAULT_UV, player.getId());
            matrices.pop();
            return;
        }
    }
}
