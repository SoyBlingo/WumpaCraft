package dev.crashmc;

import dev.crashmc.generated.Audio;
import dev.crashmc.generated.Appearance;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import java.nio.file.*;

final class CrashAudio {
    private static boolean attempted, ready;
    static boolean ready() { return ready; }
    static boolean playbackObserved;
    private static net.minecraft.client.sound.SoundInstance power;
    static void play(MinecraftClient mc,String name) {
        if(!ready)return;
        var sound=PositionedSoundInstance.master(SoundEvent.of(Identifier.of("crashmc",name)),1f,.75f);
        if(name.equals("aku_power")) {stopPower();power=sound;}
        mc.getSoundManager().play(sound);
    }
    static void stopPower() {if(power!=null){MinecraftClient.getInstance().getSoundManager().stop(power);power=null;}}
    static void prepare(MinecraftClient mc) {
        if (attempted) return;
        attempted = true;
        try {
            Path source = FabricLoader.getInstance().getConfigDir().resolve(Appearance.CACHE_FOLDER).resolve(Audio.PACK_FILE);
            Path packs = FabricLoader.getInstance().getGameDir().resolve("resourcepacks");
            Files.createDirectories(packs);
            Files.copy(source, packs.resolve(Audio.PACK_FILE), StandardCopyOption.REPLACE_EXISTING);
            var manager = mc.getResourcePackManager(); manager.scanPacks();
            if (!manager.hasProfile(Audio.PACK_ID)) throw new java.io.IOException("No se encontró el paquete de sonido");
            manager.enable(Audio.PACK_ID);
            mc.reloadResources().thenRun(() -> { ready = true; CrashClient.LOG.info("Original NST spin audio ready"); });
        } catch (Exception ex) { CrashClient.LOG.error("Cannot load local Crash sound", ex); }
    }
    static void spin(MinecraftClient mc) {
        if (ready) {
            var sound = PositionedSoundInstance.master(SoundEvent.of(Identifier.of(Audio.SPIN_SOUND)), 1f, (float)Audio.VOLUME);
            mc.getSoundManager().play(sound);
            playbackObserved |= mc.getSoundManager().isPlaying(sound);
        }
    }
}
