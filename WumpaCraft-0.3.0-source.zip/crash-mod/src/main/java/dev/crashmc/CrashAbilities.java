package dev.crashmc;

import java.util.*;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.BlockState;
import net.minecraft.entity.*;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.RaycastContext;
import net.minecraft.particle.ParticleTypes;

/** All inventory, damage and block changes execute on the integrated server. */
public final class CrashAbilities {
    public static volatile UUID playerId;
    public static volatile boolean equipped;
    public static volatile int masks, invincible, ammo, enemyKills, awardedMasks;
    public static volatile List<Vec3d> shots = List.of();
    private static final List<Shot> projectiles = new ArrayList<>();
    private static Object lastServer;
    private static long nextShot, nextSlide;
    private static int slideLeft;
    private static Vec3d previousSlidePos=Vec3d.ZERO;
    static int acceptedSlides;
    static double slideLaunchSpeed;
    private static final Set<UUID> slideHits = new HashSet<>();
    private static final class Shot {
        Vec3d pos, velocity; int life; final ServerWorld world; final UUID owner;
        Shot(ServerPlayerEntity p) { pos=p.getEyePos().add(p.getRotationVec(1).multiply(.45)); velocity=p.getRotationVec(1).multiply(1.8); world=p.getServerWorld(); owner=p.getUuid(); }
    }
    static boolean valid(ServerPlayerEntity p) {
        return p != null && p.isAlive() && !p.isSpectator() && p.getUuid().equals(playerId)
            && CrashClient.enabled && p.getServer() instanceof IntegratedServer s && !s.isRemote() && s.getCurrentPlayerCount()==1;
    }
    public static int count(PlayerEntity p, Item item) {
        int count=0; for(int i=0;i<p.getInventory().size();i++) { var s=p.getInventory().getStack(i); if(s.isOf(item))count+=s.getCount(); } return count;
    }
    static boolean consume(ServerPlayerEntity p, Item item) { return consume(p,item,1); }
    static boolean consume(ServerPlayerEntity p, Item item,int amount) {
        if(count(p,item)<amount)return false;
        int remaining=amount;
        for(int i=0;i<p.getInventory().size()&&remaining>0;i++){var stack=p.getInventory().getStack(i);if(stack.isOf(item)){int n=Math.min(remaining,stack.getCount());stack.decrement(n);remaining-=n;}}
        p.getInventory().markDirty();return true;
    }
    static void sound(String name) { var mc=net.minecraft.client.MinecraftClient.getInstance(); mc.execute(()->CrashAudio.play(mc,name)); }
    static void registerServerEvents() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if(lastServer!=server) {lastServer=server; nextShot=nextSlide=0; slideLeft=invincible=masks=0;projectiles.clear();}
            var p=playerId==null ? null : server.getPlayerManager().getPlayer(playerId);
            if(!valid(p)) {invincible=slideLeft=0;projectiles.clear();shots=List.of(); return;}
            CrashGuide.give(p);
            int stored=0; for(int i=1;i<=3;i++)if(p.getCommandTags().contains("crashmc_aku_"+i))stored=i;
            masks=stored;
            enemyKills=counter(p,"kills");awardedMasks=counter(p,"awards");
            if(invincible==0 && masks<3 && consume(p,CrashItems.AKU)) {
                setMasks(p,masks+1); sound(masks==1?"aku_one":"aku_two");
            }
            if(invincible>0) {
                invincible--;
                for(var e:p.getServerWorld().getEntitiesByClass(net.minecraft.entity.mob.MobEntity.class,p.getBoundingBox().expand(.2),e->e.isAlive() && p.canSee(e))) {
                    e.timeUntilRegen=0; e.damage(p.getServerWorld(),p.getDamageSources().playerAttack(p),Float.MAX_VALUE);
                }
                if(invincible==0) {sound("aku_end");setMasks(p,0);setCounter(p,"awards",0);setCounter(p,"kills",0);}
            }
            if(slideLeft>0) {
                slideLeft--;
                Vec3d now=p.getPos().add(0,.5,0);
                for(var e:p.getServerWorld().getEntitiesByClass(LivingEntity.class,new Box(previousSlidePos,now).expand(1.2,1,1.2),e->!(e instanceof PlayerEntity)&&e.isAlive()&&p.canSee(e))) {
                    Vec3d offset=e.getPos().subtract(p.getPos()).multiply(1,0,1);
                    var hitBox=e.getBoundingBox().expand(.8,.15,.8);
                    if(!slideHits.contains(e.getUuid()) && (hitBox.contains(now)||hitBox.contains(previousSlidePos)||hitBox.raycast(previousSlidePos,now).isPresent())) {
                        slideHits.add(e.getUuid());
                        if(e.damage(p.getServerWorld(),p.getDamageSources().playerAttack(p),6f)) {
                            Vec3d direction=now.subtract(previousSlidePos).multiply(1,0,1);
                            if(direction.lengthSquared()<.001)direction=p.getRotationVec(1).multiply(1,0,1);
                            Vec3d v=direction.normalize().multiply(1.35);e.setVelocity(v.x,.35,v.z);e.velocityModified=true;slideLaunchSpeed=e.getVelocity().horizontalLength();
                        }
                    }
                }
                previousSlidePos=now;
            }
            for(var it=projectiles.iterator();it.hasNext();) {
                var shot=it.next();
                if(shot.world!=p.getServerWorld() || ++shot.life>40) {it.remove();continue;}
                Vec3d end=shot.pos.add(shot.velocity);
                if(!shot.world.isChunkLoaded(BlockPos.ofFloored(end))) {it.remove();continue;}
                var block=shot.world.raycast(new RaycastContext(shot.pos,end,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,p));
                Vec3d stop=block.getType()==HitResult.Type.MISS?end:block.getPos();
                LivingEntity victim=null; double closest=shot.pos.squaredDistanceTo(stop);
                for(var e:shot.world.getEntitiesByClass(LivingEntity.class,new Box(shot.pos,end).expand(.6),e->!(e instanceof PlayerEntity)&&e.isAlive())) {
                    var hit=e.getBoundingBox().expand(.2).raycast(shot.pos,stop);
                    if(hit.isPresent() && shot.pos.squaredDistanceTo(hit.get())<=closest) {victim=e;closest=shot.pos.squaredDistanceTo(hit.get());}
                }
                if(victim!=null) {
                    explode(p,shot.pos.add(shot.velocity.normalize().multiply(Math.sqrt(closest))));it.remove();
                } else if(block.getType()!=HitResult.Type.MISS) {
                    explode(p,block.getPos());it.remove();
                } else {shot.pos=end;shot.world.spawnParticles(ParticleTypes.CRIT,end.x,end.y,end.z,1,0,0,0,0);}
            }
            shots=projectiles.stream().map(s->s.pos).toList();ammo=count(p,CrashItems.WUMPA);
        });
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity,source,amount)-> !(entity instanceof ServerPlayerEntity p && valid(p) && invincible>0));
        ServerLivingEntityEvents.AFTER_DEATH.register((entity,source)-> {
            if(source.getAttacker() instanceof ServerPlayerEntity p && valid(p) && !(entity instanceof PlayerEntity)) {
                var w=p.getServerWorld();drop(w,entity.getPos(),new ItemStack(CrashItems.WUMPA,4+w.random.nextInt(5)));
                if(entity instanceof HostileEntity)rewardEnemy(p,entity.getPos());
            }
            if(entity instanceof ServerPlayerEntity p && p.getUuid().equals(playerId)) {setMasks(p,0);invincible=0;setCounter(p,"awards",0);setCounter(p,"kills",0);}
        });
        PlayerBlockBreakEvents.AFTER.register((world,player,pos,state,be)-> {if(player instanceof ServerPlayerEntity p && valid(p))leafDrop(p.getServerWorld(),pos,state);});
    }
    static int counter(ServerPlayerEntity p,String name){String prefix="crashmc_"+name+"_";for(String tag:p.getCommandTags())if(tag.startsWith(prefix))try{return Integer.parseInt(tag.substring(prefix.length()));}catch(NumberFormatException ignored){}return 0;}
    static void setCounter(ServerPlayerEntity p,String name,int n){String prefix="crashmc_"+name+"_";for(String tag:new HashSet<>(p.getCommandTags()))if(tag.startsWith(prefix))p.removeCommandTag(tag);if(n>0)p.addCommandTag(prefix+n);}
    static void rewardEnemy(ServerPlayerEntity p,Vec3d pos){
        int awarded=Math.max(counter(p,"awards"),masks+count(p,CrashItems.AKU));
        if(invincible>0||awarded>=3)return;
        int kills=counter(p,"kills")+1;
        if(kills<20){setCounter(p,"kills",kills);return;}
        setCounter(p,"kills",0);setCounter(p,"awards",awarded+1);
        drop(p.getServerWorld(),pos,new ItemStack(CrashItems.AKU));sound("aku_one");
    }
    public static boolean rescue(ServerPlayerEntity p,net.minecraft.entity.damage.DamageSource source){
        if(!p.getUuid().equals(playerId)||!CrashClient.enabled||p.isSpectator()||!(p.getServer() instanceof IntegratedServer server)||server.isRemote()||server.getCurrentPlayerCount()!=1||source.isIn(net.minecraft.registry.tag.DamageTypeTags.BYPASSES_INVULNERABILITY))return false;
        int stored=0;for(int i=1;i<=3;i++)if(p.getCommandTags().contains("crashmc_aku_"+i))stored=i;
        if(stored>0)setMasks(p,stored-1);else if(!consume(p,CrashItems.AKU))return false;
        setCounter(p,"awards",Math.max(0,counter(p,"awards")-1));
        p.setHealth(8f);p.clearStatusEffects();
        p.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(net.minecraft.entity.effect.StatusEffects.REGENERATION,100,1));
        p.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(net.minecraft.entity.effect.StatusEffects.RESISTANCE,60,4));
        p.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(net.minecraft.entity.effect.StatusEffects.FIRE_RESISTANCE,200,0));
        p.getServerWorld().spawnParticles(ParticleTypes.TOTEM_OF_UNDYING,p.getX(),p.getY()+1,p.getZ(),35,.4,.7,.4,.1);
        sound("aku_lose");return true;
    }
    static void setMasks(ServerPlayerEntity p,int n) {
        for(int i=1;i<=3;i++)p.removeCommandTag("crashmc_aku_"+i);
        if(n>0)p.addCommandTag("crashmc_aku_"+n);masks=n;
    }
    static void activate(ServerPlayerEntity p) {if(valid(p)&&masks==3&&invincible==0) {invincible=400;setMasks(p,0);sound("aku_power");}}
    static void slide(ServerPlayerEntity p) {
        if(!valid(p)||p.hasVehicle()||p.isTouchingWater()||p.isInLava()||p.getServer().getTicks()<nextSlide)return;
        // Ground packets may arrive after the local action; verify actual support too.
        boolean supported=p.isOnGround()||!p.getServerWorld().isSpaceEmpty(p,p.getBoundingBox().offset(0,-.2,0));
        if(!supported)return;
        nextSlide=p.getServer().getTicks()+24;slideLeft=12;slideHits.clear();previousSlidePos=p.getPos().add(0,.5,0);acceptedSlides++;
    }
    static boolean fire(ServerPlayerEntity p) {
        if(!valid(p)||!equipped||p.hasVehicle()||p.getServer().getTicks()<nextShot)return false;
        if(!consume(p,CrashItems.WUMPA,5))return false;
        nextShot=p.getServer().getTicks()+14;projectiles.add(new Shot(p));sound("bazooka_shoot");
        net.minecraft.client.MinecraftClient.getInstance().execute(()->CrashExpansion.shotTicks=7);return true;
    }
    static void drop(ServerWorld world,Vec3d pos,ItemStack stack) {var e=new ItemEntity(world,pos.x,pos.y+.15,pos.z,stack);e.setToDefaultPickupDelay();world.spawnEntity(e);}
    static void leafDrop(ServerWorld world,BlockPos pos,BlockState state) {
        if(state.isIn(BlockTags.LEAVES)&&world.random.nextInt(100)<8){int roll=world.random.nextInt(100);drop(world,Vec3d.ofCenter(pos),new ItemStack(CrashItems.WUMPA,roll<85?1:roll<98?2:3));}
    }
    static int spinLeaves(ServerPlayerEntity p) {
        if(!valid(p)||!p.getAbilities().allowModifyWorld)return 0;
        var w=p.getServerWorld();var origin=p.getEyePos();int broken=0;BlockPos base=p.getBlockPos();
        for(BlockPos cursor:BlockPos.iterate(base.add(-3,-2,-3),base.add(3,4,3))) {
            BlockPos pos=cursor.toImmutable();if(Vec3d.ofCenter(pos).squaredDistanceTo(origin)>3.25*3.25||!w.isChunkLoaded(pos)||!w.getWorldBorder().contains(pos)||!w.canPlayerModifyAt(p,pos))continue;
            var state=w.getBlockState(pos);if(!state.isIn(BlockTags.LEAVES))continue;
            var ray=w.raycast(new RaycastContext(origin,Vec3d.ofCenter(pos),RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,p));
            if(ray.getType()!=HitResult.Type.MISS&&!ray.getBlockPos().equals(pos))continue;
            if(!PlayerBlockBreakEvents.BEFORE.invoker().beforeBlockBreak(w,p,pos,state,w.getBlockEntity(pos)))continue;
            if(w.breakBlock(pos,true,p)){leafDrop(w,pos,state);broken++;}
        }
        return broken;
    }
    static void explode(ServerPlayerEntity p,Vec3d impact) {
        var world=p.getServerWorld();
        world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER,impact.x,impact.y,impact.z,1,0,0,0,0);
        world.spawnParticles(ParticleTypes.FLAME,impact.x,impact.y,impact.z,25,.6,.6,.6,.05);
        world.spawnParticles(ParticleTypes.LARGE_SMOKE,impact.x,impact.y,impact.z,18,.8,.8,.8,.03);
        world.playSound(null,BlockPos.ofFloored(impact),net.minecraft.sound.SoundEvents.ENTITY_GENERIC_EXPLODE.value(),net.minecraft.sound.SoundCategory.PLAYERS,.9f,1.1f);
        sound("bazooka_impact");
        for(var target:world.getEntitiesByClass(LivingEntity.class,new Box(impact,impact).expand(3),e->!(e instanceof PlayerEntity)&&e.isAlive())) {
            Vec3d center=target.getBoundingBox().getCenter();double distance=center.distanceTo(impact);if(distance>3)continue;
            var occlusion=world.raycast(new RaycastContext(impact,center,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,p));
            if(occlusion.getType()!=HitResult.Type.MISS&&occlusion.getPos().distanceTo(center)>.4)continue;
            if(target.damage(world,p.getDamageSources().playerAttack(p),(float)(10*(1-distance/4)))) {
                Vec3d push=center.subtract(impact).multiply(1,0,1).normalize().multiply(.9);target.setVelocity(push.x,.4,push.z);target.velocityModified=true;
            }
        }
        breakCluster(p,BlockPos.ofFloored(impact));
    }
    static int breakCluster(ServerPlayerEntity p,BlockPos center) {
        int broken=0; var world=p.getServerWorld();var positions=new ArrayList<BlockPos>();
        for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++)for(int z=-1;z<=1;z++)positions.add(center.add(x,y,z));
        for(var pos:positions) {
            if(!world.isChunkLoaded(pos)||!world.getWorldBorder().contains(pos)||!world.canPlayerModifyAt(p,pos)||p.isSpectator()||!p.getAbilities().allowModifyWorld)continue;
            var state=world.getBlockState(pos);
            if(state.isAir()||state.getHardness(world,pos)<0)continue;
            if(!PlayerBlockBreakEvents.BEFORE.invoker().beforeBlockBreak(world,p,pos,state,world.getBlockEntity(pos)))continue;
            if(world.breakBlock(pos,true,p)) {broken++;leafDrop(world,pos,state);}
        }
        return broken;
    }
}
