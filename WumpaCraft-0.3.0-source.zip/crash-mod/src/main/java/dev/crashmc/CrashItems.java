package dev.crashmc;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.*;
import net.minecraft.registry.*;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

public final class CrashItems implements ModInitializer {
    public static final Item WUMPA = register("wumpa", true);
    public static final Item AKU = register("aku_aku", false);
    private static Item register(String name, boolean food) {
        var key = RegistryKey.of(RegistryKeys.ITEM, Identifier.of("crashmc", name));
        var settings = new Item.Settings().registryKey(key).maxCount(64);
        if (food) settings.food(new FoodComponent.Builder().nutrition(2).saturationModifier(.3f).alwaysEdible().build());
        Item item = food ? new Item(settings) {
            @Override public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
                if (!world.isClient) user.heal(2f);
                return super.finishUsing(stack, world, user);
            }
        } : new Item(settings);
        return Registry.register(Registries.ITEM, key, item);
    }
    @Override public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FOOD_AND_DRINK).register(e -> e.add(WUMPA));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(e -> e.add(AKU));
        CrashAbilities.registerServerEvents();
    }
}
