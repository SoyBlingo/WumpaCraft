package dev.crashmc;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.Vec3d;

public final class CrashExpansion {
    static KeyBinding slideKey,bazookaKey,akuKey;
    public static int slideTicks,shotTicks,equipTicks;
    private static int slideCooldown,fireCooldown,previousAmmo;
    private static Vec3d slideDirection=Vec3d.ZERO;
    private static boolean wasActive;
    private static boolean slideHeld;
    private static boolean slideQueued;
    public static int slideSerial;
    public static void keyPressed(int key,int scanCode) {
        if(slideKey!=null&&slideKey.matchesKey(key,scanCode)&&MinecraftClient.getInstance().currentScreen==null)slideQueued=true;
    }
    public static boolean aiming;
    static void init() {
        slideKey=key("slide",67);bazookaKey=key("bazooka",90);akuKey=key("aku",86);
        HudRenderCallback.EVENT.register((ctx,counter)-> {
            var mc=MinecraftClient.getInstance();if(!CrashClient.active()||mc.options.hudHidden)return;
            String power=CrashAbilities.invincible>0 ? "INVENCIBLE: "+((CrashAbilities.invincible+19)/20)+" s" : "Aku Aku: "+CrashAbilities.masks+"/3"+(CrashAbilities.masks==3?"  [V: activar]":"");
            ctx.drawTextWithShadow(mc.textRenderer,"Wumpa: "+CrashAbilities.ammo+"   |   "+power,8,20,0xFFFFD66B);
            ctx.drawTextWithShadow(mc.textRenderer,slideKey.getBoundKeyLocalizedText().getString()+": deslizar"+(slideTicks>0?" ¡YA!":slideCooldown>0?" ...":"")+"  Z: bazooka"+(CrashAbilities.equipped?"  Der.: apuntar  Izq.: disparar":""),8,32,0xFFFFFFFF);
            CrashScope.draw(ctx);
            String progress=CrashAbilities.invincible>0?"Aku Aku: invencible "+((CrashAbilities.invincible+19)/20)+" s":CrashAbilities.masks==3?"Aku Aku: listo ["+akuKey.getBoundKeyLocalizedText().getString()+"]":CrashAbilities.awardedMasks>=3?"Aku Aku: recoge tus máscaras":"Aku Aku: "+CrashAbilities.enemyKills+"/20 enemigos";
            int right=ctx.getScaledWindowWidth()-8,left=right-mc.textRenderer.getWidth(progress);
            int top=mc.player.getStatusEffects().isEmpty()?4:58;
            ctx.fill(left-5,top,right+4,top+18,0xB51C142D);
            ctx.fill(left-5,top+17,right+4,top+18,0xFFD5A64A);
            ctx.drawTextWithShadow(mc.textRenderer,progress,left,top+4,0xFFEBD1FF);
        });
    }
    static KeyBinding key(String name,int code) {return KeyBindingHelper.registerKeyBinding(new KeyBinding("key.crashmc."+name,InputUtil.Type.KEYSYM,code,"key.categories.crashmc"));}
    public static boolean intercept() {var mc=MinecraftClient.getInstance();return CrashAbilities.equipped&&CrashClient.active()&&mc.currentScreen==null;}
    static void reset() {CrashScope.tick(MinecraftClient.getInstance(),false);slideQueued=slideHeld=false;CrashAbilities.playerId=null;CrashAbilities.equipped=false;aiming=false;slideTicks=shotTicks=equipTicks=slideCooldown=fireCooldown=0;wasActive=false;CrashAudio.stopPower();}
    static void tick(MinecraftClient mc) {
        if(!CrashClient.active()) {reset();return;}
        CrashAbilities.playerId=mc.player.getUuid();
        int reserve=CrashAbilities.count(mc.player,CrashItems.WUMPA);
        if(wasActive&&reserve>previousAmmo)CrashAudio.play(mc,"wumpa_collect");
        previousAmmo=reserve;wasActive=true;
        if(CrashAbilities.invincible==0)CrashAudio.stopPower();
        if(mc.isPaused())return;
        if(slideCooldown>0)slideCooldown--;if(fireCooldown>0)fireCooldown--;if(shotTicks>0)shotTicks--;if(equipTicks>0)equipTicks--;
        if(mc.currentScreen!=null) {aiming=false;CrashScope.tick(mc,false);while(slideKey.wasPressed()){}while(bazookaKey.wasPressed()){}while(akuKey.wasPressed()){}return;}
        while(bazookaKey.wasPressed()) {CrashAbilities.equipped=!CrashAbilities.equipped;equipTicks=8;slideTicks=0;CrashAudio.play(mc,"bazooka_equip");}
        aiming=CrashAbilities.equipped&&mc.options.useKey.isPressed();
        while(akuKey.wasPressed()) {var id=mc.player.getUuid();mc.getServer().execute(()->CrashAbilities.activate(mc.getServer().getPlayerManager().getPlayer(id)));}
        // Vanilla also binds C to saving creative toolbars. Read the configured
        // key's rising edge so that its single-binding map cannot swallow C.
        var bound=KeyBindingHelper.getBoundKeyOf(slideKey);
        boolean held=bound.getCategory()==InputUtil.Type.KEYSYM && bound.getCode()>=0 && InputUtil.isKeyPressed(mc.getWindow().getHandle(),bound.getCode());
        boolean requested=slideQueued||(held&&!slideHeld);slideQueued=false;slideHeld=held;
        while(slideKey.wasPressed())requested=true;
        if(requested) {
            if(slideCooldown==0&&mc.player.isOnGround()&&!mc.player.hasVehicle()&&!mc.player.isTouchingWater()&&!mc.player.isInLava()) {
                CrashAbilities.equipped=false;aiming=false;equipTicks=0;slideSerial++;
                CrashAudio.play(mc,"slide");
                slideTicks=12;slideCooldown=24;slideDirection=mc.player.getRotationVec(1).multiply(1,0,1).normalize();
                var server=mc.getServer();var id=mc.player.getUuid();server.execute(()->CrashAbilities.slide(server.getPlayerManager().getPlayer(id)));
            }
        }
        if(slideTicks>0) {
            slideTicks--;if((slideTicks<10&&mc.player.horizontalCollision)||!mc.player.isOnGround())slideTicks=0;
            else {Vec3d v=slideDirection.multiply(.65);mc.player.setVelocity(v.x,mc.player.getVelocity().y,v.z);}
        }
        if(CrashAbilities.equipped&&mc.options.attackKey.isPressed()&&fireCooldown==0) {
            fireCooldown=14;var server=mc.getServer();var id=mc.player.getUuid();server.execute(()->CrashAbilities.fire(server.getPlayerManager().getPlayer(id)));
            if(reserve<5)mc.player.sendMessage(net.minecraft.text.Text.literal("Necesitas 5 Wumpas por disparo"),true);
        }
        CrashScope.tick(mc,aiming);
    }
}
