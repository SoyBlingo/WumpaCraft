package dev.crashmc.mixin;
import dev.crashmc.CrashAbilities;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(LivingEntity.class)
public abstract class CrashAkuMixin {
 @Inject(method="tryUseDeathProtector",at=@At("HEAD"),cancellable=true)
 private void crashmc$rescue(DamageSource source,CallbackInfoReturnable<Boolean> ci){
  if((Object)this instanceof ServerPlayerEntity p && CrashAbilities.rescue(p,source))ci.setReturnValue(true);
 }
}
