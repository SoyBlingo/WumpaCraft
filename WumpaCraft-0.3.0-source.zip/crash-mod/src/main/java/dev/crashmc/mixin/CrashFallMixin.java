package dev.crashmc.mixin;

import dev.crashmc.CrashClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class CrashFallMixin {
    @Inject(method="handleFallDamage", at=@At("HEAD"), cancellable=true)
    private void crashmc$landing(float distance, float multiplier, DamageSource source, CallbackInfoReturnable<Boolean> ci) {
        if (CrashClient.protectsFromFall((LivingEntity)(Object)this)) ci.setReturnValue(false);
    }
}
