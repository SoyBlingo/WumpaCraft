package dev.crashmc.mixin;
import dev.crashmc.CrashExpansion;
import net.minecraft.client.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Keyboard.class)
public abstract class CrashKeyboardMixin {
    @Inject(method="onKey",at=@At("HEAD"))
    private void crashmc$key(long window,int key,int scanCode,int action,int modifiers,CallbackInfo ci) {
        if(action==1)CrashExpansion.keyPressed(key,scanCode);
    }
}
