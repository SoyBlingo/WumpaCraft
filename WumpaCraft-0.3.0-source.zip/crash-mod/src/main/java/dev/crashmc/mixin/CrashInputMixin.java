package dev.crashmc.mixin;
import dev.crashmc.CrashExpansion;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.*;

@Mixin(MinecraftClient.class)
public abstract class CrashInputMixin {
    @Inject(method="doAttack",at=@At("HEAD"),cancellable=true)
    private void crashmc$attack(CallbackInfoReturnable<Boolean> ci) {if(CrashExpansion.intercept())ci.setReturnValue(false);}
    @Inject(method="handleBlockBreaking",at=@At("HEAD"),cancellable=true)
    private void crashmc$break(boolean breaking,CallbackInfo ci) {if(CrashExpansion.intercept())ci.cancel();}
    @Inject(method="doItemUse",at=@At("HEAD"),cancellable=true)
    private void crashmc$use(CallbackInfo ci) {if(dev.crashmc.CrashGuide.openHeld()||CrashExpansion.intercept())ci.cancel();}
}
