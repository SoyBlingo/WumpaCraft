package dev.crashmc.mixin;

import dev.crashmc.CrashClient;
import dev.crashmc.CrashModel;
import dev.crashmc.CrashProps;
import dev.crashmc.generated.Hooks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Renders the active Crash player and custom props. See third-party notices. */
@Mixin(EntityRenderDispatcher.class)
public abstract class CrashRenderMixin {
    @Inject(method = Hooks.RENDER_TARGET, at = @At("HEAD"), cancellable = true)
    private void crashmc$render(Entity entity, double x, double y, double z, float delta,
            MatrixStack matrices, VertexConsumerProvider consumers, int light, CallbackInfo ci) {
        if(CrashProps.renderItem(entity,x,y,z,delta,matrices,consumers,light)) {ci.cancel();return;}
        if (entity == MinecraftClient.getInstance().player && CrashClient.active()) {
            CrashModel.render(entity, x, y, z, delta, matrices, consumers, light);
            ci.cancel();
        }
    }
}
