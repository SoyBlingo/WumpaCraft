package dev.crashmc.mixin;
import dev.crashmc.CrashScope;
import net.minecraft.client.render.GameRenderer;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class CrashScopeMixin {
    @ModifyReturnValue(method="getFov",at=@At("RETURN"))
    private float crashmc$zoom(float original) {return CrashScope.fov(original);}
    @Inject(method="renderHand",at=@At("HEAD"),cancellable=true)
    private void crashmc$scopeHands(CallbackInfo ci) {if(CrashScope.active())ci.cancel();}
}
