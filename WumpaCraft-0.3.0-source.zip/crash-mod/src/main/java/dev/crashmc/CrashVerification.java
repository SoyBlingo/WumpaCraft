package dev.crashmc;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.PigEntity;
import java.nio.file.*;
import java.util.*;

/** Opt-in development-only integration check. Never runs in installed builds. */
final class CrashVerification {
    private static final Path root = FabricLoader.getInstance().getConfigDir().resolve("crashmc");
    private static int stage = -1, serial;
    private static double startY, peak;
    private static float health, lowestHealth;
    private static volatile PigEntity target;
    private static volatile boolean fallProtected;
    private static volatile double knockback, lift, displacement;
    private static volatile float damage;
    private static net.minecraft.util.math.Vec3d targetStart;
    static void tick(MinecraftClient mc) {
        if (!CrashClient.active() || mc.isPaused() || mc.currentScreen != null || !CrashAudio.ready()) return;
        if (stage < 0) {
            if (stage == -2 || !Files.exists(root.resolve("verify.request")) || !mc.player.isOnGround()) return;
            try { Files.move(root.resolve("verify.request"), root.resolve("verify.started"), StandardCopyOption.REPLACE_EXISTING); }
            catch (Exception ex) { stage = -2; return; }
            stage = 0; serial = CrashClient.jumpSerial; startY = peak = mc.player.getY(); health = lowestHealth = mc.player.getHealth();
            mc.getServer().execute(() -> {
                var sp = mc.getServer().getPlayerManager().getPlayer(mc.player.getUuid());
                float before = sp.getHealth();
                sp.handleFallDamage(8f, 1f, sp.getServerWorld().getDamageSources().fall());
                fallProtected = sp.getHealth() == before;
                if (!fallProtected) sp.setHealth(before);
                target = new PigEntity(EntityType.PIG, sp.getServerWorld());
                target.setPosition(sp.getX() + 2.8, sp.getY(), sp.getZ() + .2);
                targetStart = target.getPos(); sp.getServerWorld().spawnEntity(target);
            });
            CrashClient.LOG.info("CRASH_VERIFY started: original health {}, y {}", health, startY);
        }
        stage++;
        peak = Math.max(peak, mc.player.getY()); lowestHealth = Math.min(lowestHealth, mc.player.getHealth());
        // Set normal bindings across complete game ticks so input cannot be missed.
        if (stage == 20) KeyBinding.onKeyPressed(InputUtil.fromKeyCode(82, 0));
        if (stage == 23) {
            mc.getServer().execute(() -> {
                if (target != null) { damage = target.getMaxHealth() - target.getHealth(); knockback = target.getVelocity().horizontalLength(); lift = target.getVelocity().y; }
            });
            screenshot();
        }
        if (stage == 35) mc.getServer().execute(() -> { if (target != null) displacement = target.getPos().distanceTo(targetStart); });
        if (stage == 40 || stage == 48) mc.options.jumpKey.setPressed(true);
        if (stage == 42 || stage == 50) mc.options.jumpKey.setPressed(false);
        if (stage == 52) screenshot();
        if (stage == 100) mc.options.forwardKey.setPressed(true);
        if (stage == 112 || stage == 124) screenshot();
        if (stage == 128) mc.options.forwardKey.setPressed(false);
        if (stage >= 140 && mc.player.isOnGround() || stage >= 180) {
            mc.options.jumpKey.setPressed(false);
            mc.options.forwardKey.setPressed(false);
            Map<String,Object> results = new LinkedHashMap<>();
            results.put("fallDamageHandlerProtected", fallProtected);
            results.put("spinDamage", damage); results.put("spinHorizontalVelocityAfterHit", knockback);
            results.put("spinVerticalVelocityAfterHit", lift); results.put("targetDisplacement", displacement);
            results.put("jumpActivations", CrashClient.jumpSerial - serial); results.put("jumpHeight", peak - startY);
            results.put("healthBefore", health); results.put("lowestHealth", lowestHealth); results.put("healthAfter", mc.player.getHealth());
            results.put("landed", mc.player.isOnGround()); results.put("soundPlayingObserved", CrashAudio.playbackObserved);
            results.put("renderedAnimationStates", new ArrayList<>(CrashMotion.observedStates));
            try { Files.writeString(root.resolve("verification.json"), new com.google.gson.GsonBuilder().setPrettyPrinting().create().toJson(results)); }
            catch (Exception ex) { CrashClient.LOG.error("Cannot save checks", ex); }
            CrashClient.LOG.info("CRASH_VERIFY {}", results);
            mc.getServer().execute(() -> { if (target != null) target.discard(); });
            screenshot(); stage = -2;
        }
    }
    private static void screenshot() {
        var mc = MinecraftClient.getInstance();
        net.minecraft.client.util.ScreenshotRecorder.saveScreenshot(mc.runDirectory, "crash-check-" + stage + ".png", mc.getFramebuffer(), text -> CrashClient.LOG.info("Verification screenshot: {}", text.getString()));
    }
}
