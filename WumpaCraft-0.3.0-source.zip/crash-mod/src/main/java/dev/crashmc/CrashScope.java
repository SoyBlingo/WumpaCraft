package dev.crashmc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.Perspective;

public final class CrashScope {
    private static Perspective previous;
    public static boolean active() {return previous!=null&&CrashExpansion.aiming&&CrashClient.active();}
    public static float fov(float original) {return active()?original*.38f:original;}
    static void tick(MinecraftClient mc,boolean aiming) {
        if(aiming) {
            if(previous==null)previous=mc.options.getPerspective();
            mc.options.setPerspective(Perspective.FIRST_PERSON);
        }else if(previous!=null) {mc.options.setPerspective(previous);previous=null;}
    }
    static void draw(DrawContext ctx) {
        if(!active())return;
        int width=ctx.getScaledWindowWidth(),height=ctx.getScaledWindowHeight(),x=width/2,y=height/2;
        int radius=Math.max(24,(int)(Math.min(width,height)*.43));
        // Circular scope aperture, a fine reticle and visible range marks.
        for(int row=0;row<height;row+=2) {
            int dy=row-y;int half=Math.abs(dy)<radius?(int)Math.sqrt(radius*radius-dy*dy):0;
            ctx.fill(0,row,x-half,Math.min(height,row+2),0xE8000000);ctx.fill(x+half,row,width,Math.min(height,row+2),0xE8000000);
        }
        int color=0xFFE0F4AA;
        ctx.fill(x-radius+5,y,x-6,y+1,color);ctx.fill(x+7,y,x+radius-5,y+1,color);
        ctx.fill(x,y-radius+5,x+1,y-6,color);ctx.fill(x,y+7,x+1,y+radius-5,color);
        ctx.fill(x-1,y-1,x+2,y+2,0xFFFF5D38);
        for(int n=1;n<=3;n++) {int gap=n*radius/5;ctx.fill(x-3,y+gap,x+4,y+gap+1,color);ctx.fill(x+gap,y-3,x+gap+1,y+4,color);ctx.fill(x-gap,y-3,x-gap+1,y+4,color);}
    }
}
