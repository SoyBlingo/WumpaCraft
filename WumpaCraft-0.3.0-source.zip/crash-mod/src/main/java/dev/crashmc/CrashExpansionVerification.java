package dev.crashmc;

import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.*;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.item.*;
import net.minecraft.block.*;
import net.minecraft.util.math.*;
import java.nio.file.*;
import java.util.*;

/** Explicit opt-in, development-only integrated-server checks, with restoration. */
final class CrashExpansionVerification {
    static final Path root=FabricLoader.getInstance().getConfigDir().resolve("crashmc");
    static boolean ran;
    static int stage;
    static final Map<String,Object> result=new LinkedHashMap<>();
    static List<ItemStack> inventory;
    static float health,saturation;static int hunger;
    static int savedMasks;
    static PigEntity pig;static ZombieEntity zombie;
    static void tick(MinecraftClient mc) {
        if(!CrashClient.active()||mc.isPaused()||mc.currentScreen!=null||!CrashAudio.ready())return;
        if(!ran) {
            if(!Files.exists(root.resolve("expansion-test.request")))return;
            ran=true;stage=0;
            try {Files.move(root.resolve("expansion-test.request"),root.resolve("expansion-test.started"),StandardCopyOption.REPLACE_EXISTING);}catch(Exception ex){return;}
        }
        if(stage<0)return;
        stage++;
        var server=mc.getServer();var id=mc.player.getUuid();
        if(stage==1)server.execute(()-> {
            var p=server.getPlayerManager().getPlayer(id);var w=p.getServerWorld();inventory=new ArrayList<>();for(int i=0;i<p.getInventory().size();i++)inventory.add(p.getInventory().getStack(i).copy());
            health=p.getHealth();hunger=p.getHungerManager().getFoodLevel();saturation=p.getHungerManager().getSaturationLevel();savedMasks=CrashAbilities.masks;
            p.getInventory().clear();p.getInventory().insertStack(new ItemStack(CrashItems.WUMPA,64));p.getInventory().insertStack(new ItemStack(CrashItems.WUMPA,64));
            p.setHealth(16);p.getHungerManager().setFoodLevel(14);var food=new ItemStack(CrashItems.WUMPA,2);var remaining=CrashItems.WUMPA.finishUsing(food,w,p);
            result.put("foodHealsOneHeart",p.getHealth()==18);result.put("foodRestoresOneHungerIcon",p.getHungerManager().getFoodLevel()==16);result.put("foodConsumesOne",remaining.getCount()==1);
            BlockPos center=p.getBlockPos().add(0,60,0);var positions=new ArrayList<BlockPos>();for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++)for(int z=-1;z<=1;z++)positions.add(center.add(x,y,z));var states=new ArrayList<BlockState>();for(var pos:positions){states.add(w.getBlockState(pos));w.setBlockState(pos,Blocks.OAK_LOG.getDefaultState());}
            int broken=CrashAbilities.breakCluster(p,center);result.put("bazookaBreaks27",broken==27);
            var drops=w.getEntitiesByClass(ItemEntity.class,new Box(center).expand(3),e->e.getStack().isOf(Items.OAK_LOG));result.put("blockItemsDropped",drops.stream().mapToInt(e->e.getStack().getCount()).sum());for(var e:drops)e.discard();
            for(var pos:positions)w.setBlockState(pos,Blocks.BEDROCK.getDefaultState());result.put("unbreakableProtected",CrashAbilities.breakCluster(p,center)==0);
            for(int i=0;i<positions.size();i++)w.setBlockState(positions.get(i),states.get(i));
            for(int i=0;i<128;i++)CrashAbilities.leafDrop(w,center,Blocks.OAK_LEAVES.getDefaultState());var fruits=w.getEntitiesByClass(ItemEntity.class,new Box(center).expand(3),e->e.getStack().isOf(CrashItems.WUMPA));result.put("leavesProduceWumpa",!fruits.isEmpty());for(var e:fruits)e.discard();
            CrashAbilities.equipped=true;int before=CrashAbilities.count(p,CrashItems.WUMPA);float oldPitch=p.getPitch();p.setPitch(-90);result.put("shotAccepted",CrashAbilities.fire(p));p.setPitch(oldPitch);result.put("shotConsumes5",CrashAbilities.count(p,CrashItems.WUMPA)==before-5);result.put("cooldownRejectsSpam",!CrashAbilities.fire(p));
        });
        if(stage==20)server.execute(()-> {var p=server.getPlayerManager().getPlayer(id);p.getInventory().clear();result.put("cannotShootWithoutWumpa",!CrashAbilities.fire(p));CrashAbilities.equipped=false;p.getInventory().insertStack(new ItemStack(CrashItems.AKU,3));});
        if(stage==28)server.execute(()-> {
            var p=server.getPlayerManager().getPlayer(id);result.put("threeMasksStored",CrashAbilities.masks==3&&CrashAbilities.invincible==0);float before=p.getHealth();p.timeUntilRegen=0;p.damage(p.getServerWorld(),p.getDamageSources().generic(),1);result.put("chargedMaskDoesNotAutoProtect",p.getHealth()<before);
            CrashAbilities.activate(p);result.put("manualPowerActivated",CrashAbilities.invincible==400);before=p.getHealth();p.timeUntilRegen=0;p.damage(p.getServerWorld(),p.getDamageSources().generic(),4);result.put("powerBlocksDamage",p.getHealth()==before);
            zombie=new ZombieEntity(EntityType.ZOMBIE,p.getServerWorld());zombie.setAiDisabled(true);zombie.setPosition(p.getPos());p.getServerWorld().spawnEntity(zombie);
            pig=new PigEntity(EntityType.PIG,p.getServerWorld());pig.setAiDisabled(true);pig.setPosition(p.getPos().add(.1,0,.1));p.getServerWorld().spawnEntity(pig);
        });
        if(stage==32)server.execute(()-> {result.put("contactKillsHostile",zombie!=null&&!zombie.isAlive());result.put("contactKillsPassive",pig!=null&&!pig.isAlive());});
        if(stage==45) {CrashAbilities.equipped=true;CrashExpansion.equipTicks=0;mc.options.setPerspective(net.minecraft.client.option.Perspective.THIRD_PERSON_BACK);mc.options.useKey.setPressed(true);}
        if(stage==50) {result.put("scopeFirstPerson",mc.options.getPerspective()==net.minecraft.client.option.Perspective.FIRST_PERSON);result.put("scopeZoom",CrashScope.fov(70f));}
        if(stage==55)mc.options.useKey.setPressed(false);
        if(stage==58)result.put("scopeRestoresCamera",mc.options.getPerspective()==net.minecraft.client.option.Perspective.THIRD_PERSON_BACK);
        if(stage==50||stage==70) screenshot(mc);
        if(stage==60) {CrashAbilities.equipped=false;CrashExpansion.slideTicks=12;}
        if(stage==435)server.execute(()-> {
            result.put("powerExpires",CrashAbilities.invincible==0);result.put("powerResetsMasks",CrashAbilities.masks==0);
            var p=server.getPlayerManager().getPlayer(id);if(pig!=null)pig.discard();if(zombie!=null)zombie.discard();
            p.getInventory().clear();for(int i=0;i<inventory.size();i++)p.getInventory().setStack(i,inventory.get(i));p.setHealth(health);p.getHungerManager().setFoodLevel(hunger);p.getHungerManager().setSaturationLevel(saturation);CrashAbilities.setMasks(p,savedMasks);
            try {Files.writeString(root.resolve("expansion-test.json"),new GsonBuilder().setPrettyPrinting().create().toJson(result));}catch(Exception ex){CrashClient.LOG.error("Cannot save verification",ex);}CrashClient.LOG.info("CRASH_EXPANSION_VERIFY {}",result);
        });
        if(stage==440) {CrashAbilities.equipped=false;stage=-1;}
    }
    private static void screenshot(MinecraftClient mc) {net.minecraft.client.util.ScreenshotRecorder.saveScreenshot(mc.runDirectory,"crash-expansion-"+stage+".png",mc.getFramebuffer(),text->{});}
}
