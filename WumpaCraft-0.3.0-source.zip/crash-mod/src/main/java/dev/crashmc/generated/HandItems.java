package dev.crashmc.generated;
// Generated from design/systems.json. Edit the sheet first.
public final class HandItems {
    public static final String LEFT_BONE = "Bone_L_Hand";
    public static final String RIGHT_BONE = "Bone_R_Hand";
    public static final double SCALE = 0.75;
}
