package dev.crashmc.generated;
// Generated from design/systems.json. Edit the sheet first.
public final class Appearance {
    public static final String CACHE_FOLDER = "crashmc";
    public static final int MODEL_FORMAT = 1;
    public static final int MODEL_MAGIC = 1129464147;
    public static final double MODEL_HEIGHT = 1.8;
    public static final int BONE_INFLUENCES = 8;
    public static final double WALK_FREQUENCY = 0.7;
    public static final double WALK_SWING = 0.6;
}
