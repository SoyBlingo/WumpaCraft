package dev.crashmc.generated;
// Generated from design/systems.json. Edit the sheet first.
public final class Motion {
    public static final String CACHE_FILE = "motion.bin.gz";
    public static final int MAGIC = 1129467185;
    public static final double BLEND_TICKS = 2.0;
}
