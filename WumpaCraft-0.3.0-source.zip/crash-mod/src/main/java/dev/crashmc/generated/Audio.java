package dev.crashmc.generated;
// Generated from design/systems.json. Edit the sheet first.
public final class Audio {
    public static final String PACK_FILE = "crashmc-local-audio.zip";
    public static final String PACK_ID = "file/crashmc-local-audio.zip";
    public static final String SPIN_SOUND = "crashmc:spin";
    public static final double VOLUME = 0.8;
    public static final double FADE_SECONDS = 0.025;
}
