package dev.crashmc.generated;
// Generated from design/systems.json. Edit the sheet first.
public final class Hooks {
    public static final String MINECRAFT = "1.21.4";
    public static final String LOADER = "0.16.10";
    public static final String FABRIC_API = "0.119.4+1.21.4";
    public static final String RENDER_TARGET = "render(Lnet/minecraft/entity/Entity;DDDFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V";
    public static final String TICK_PHASE = "START_CLIENT_TICK";
    public static final String ENVIRONMENT = "client";
}
