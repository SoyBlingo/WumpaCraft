package dev.crashmc.generated;
// Generated from design/systems.json. Edit the sheet first.
public final class Spin {
    public static final int DURATION_TICKS = 9;
    public static final int COOLDOWN_TICKS = 16;
    public static final double RADIUS = 3.25;
    public static final double DAMAGE = 6.0;
    public static final double KNOCKBACK = 1.5;
    public static final double ROTATIONS = 3.0;
    public static final double KNOCKBACK_UP = 0.45;
}
