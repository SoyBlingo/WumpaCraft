package dev.crashmc.generated;
// Generated from design/systems.json. Edit the sheet first.
public final class Jump {
    public static final double VELOCITY = 0.58;
    public static final int EXTRA_AIR_JUMPS = 1;
    public static final boolean FALL_DAMAGE = false;
}
