package dev.crashmc.generated;
// Generated from design/systems.json. Edit the sheet first.
public final class Controls {
    public static final int SPIN_KEY = 82;
    public static final int TOGGLE_KEY = 295;
    public static final String CATEGORY = "key.categories.crashmc";
    public static final boolean SOLO_ONLY = true;
}
