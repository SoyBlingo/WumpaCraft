package dev.crashmc;

import com.google.gson.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.texture.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.*;

/** Owned-game prop meshes loaded exclusively from the user's local cache. */
public final class CrashProps {
    private record Mesh(int material,float[] vertices,int[] indices,int[] joints,float[] animated) {}
    private record Prop(Identifier[] textures,Mesh[] meshes,PropMotion motion) {}
    private static final Map<String,Prop> props=new HashMap<>();
    private static boolean attempted;
    static void init() {
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            var mc=MinecraftClient.getInstance();if(!CrashClient.active())return;
            var matrices=context.matrixStack();if(matrices==null||context.consumers()==null)return;
            var camera=context.camera().getPos();float delta=context.tickCounter().getTickDelta(false);
            for(Vec3d p:CrashAbilities.shots) {
                matrices.push();matrices.translate(p.x-camera.x,p.y-camera.y,p.z-camera.z);
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((mc.player.age+delta)*35));draw("wumpa",matrices,context.consumers(),LightmapTextureManager.MAX_LIGHT_COORDINATE,1,1,1);matrices.pop();
            }
            if(CrashAbilities.masks>0||CrashAbilities.invincible>0) {
                Vec3d pos=mc.player.getLerpedPos(delta);double yaw=Math.toRadians(mc.player.getYaw());boolean power=CrashAbilities.invincible>0;
                double side=power?.45:.85,back=power?.3:-.4;
                matrices.push();matrices.translate(pos.x-camera.x+Math.cos(yaw)*side-Math.sin(yaw)*back,pos.y-camera.y+1.6+Math.sin((mc.player.age+delta)*.09)*.08,pos.z-camera.z+Math.sin(yaw)*side+Math.cos(yaw)*back);
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-mc.player.getYaw()));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float)Math.sin((mc.player.age+delta)*.06)*5));
                float green=CrashAbilities.masks>=2||power?.8f:1f;draw("aku",matrices,context.consumers(),power?LightmapTextureManager.MAX_LIGHT_COORDINATE:WorldRenderer.getLightmapCoordinates(context.world(),BlockPos.ofFloored(pos)),1,green,power?.35f:1);matrices.pop();
            }
        });
    }
    static void load() {
        if(attempted)return;attempted=true;
        Path root=FabricLoader.getInstance().getConfigDir().resolve("crashmc/props");
        for(String key:List.of("bazooka","aku","wumpa"))try {
            var data=JsonParser.parseString(Files.readString(root.resolve(key+".json"))).getAsJsonObject();var materials=data.getAsJsonArray("materials");var textures=new Identifier[materials.size()];
            for(int i=0;i<textures.length;i++) {String name=materials.get(i).getAsJsonObject().get("texture").getAsString();if(!name.matches("[a-z0-9_]+\\.png"))throw new IOException("Textura inválida");try(var s=Files.newInputStream(root.resolve(name))) {textures[i]=Identifier.of("crashmc","prop_"+key+"_"+i);MinecraftClient.getInstance().getTextureManager().registerTexture(textures[i],new NativeImageBackedTexture(NativeImage.read(s)));}}
            Mesh[] meshes;
            try(var in=new DataInputStream(new BufferedInputStream(Files.newInputStream(root.resolve(key+".bin"))))) {
                if(in.readInt()!=0x43524153)throw new IOException("Prop inválido");int count=in.readInt();if(count<1||count>128)throw new IOException("Mallas inválidas");meshes=new Mesh[count];
                for(int m=0;m<count;m++) {int material=in.readInt(),n=in.readInt(),ni=in.readInt();if(material<0||material>=textures.length||n<1||n>100000||ni<3||ni>600000||ni%3!=0)throw new IOException("Datos inválidos");float[] vs=new float[n*16];int[] js=new int[n*8],ix=new int[ni];for(int v=0;v<n;v++){for(int k=0;k<16;k++){float f=in.readFloat();if(!Float.isFinite(f))throw new IOException("Vértice inválido");vs[v*16+k]=f;}for(int k=0;k<8;k++)js[v*8+k]=in.readInt();}for(int i=0;i<ni;i++){ix[i]=in.readInt();if(ix[i]<0||ix[i]>=n)throw new IOException("Índice inválido");}meshes[m]=new Mesh(material,vs,ix,js,new float[vs.length]);}
            }
            PropMotion motion=key.equals("aku")?new PropMotion(root.resolve("aku-motion.bin.gz"),data.getAsJsonArray("joints").size()):null;
            props.put(key,new Prop(textures,meshes,motion));CrashClient.LOG.info("Original prop loaded: {}",key);
        }catch(Exception ex){CrashClient.LOG.error("Prop failed: "+key,ex);}
    }
    public static boolean renderItem(Entity entity,double x,double y,double z,float delta,MatrixStack matrices,VertexConsumerProvider consumers,int light) {
        if(!(entity instanceof ItemEntity item)||!CrashClient.active())return false;
        String key=item.getStack().isOf(CrashItems.WUMPA)?"wumpa":item.getStack().isOf(CrashItems.AKU)?"aku":null;
        if(key==null||!props.containsKey(key))return false;
        matrices.push();matrices.translate(x,y+.25+Math.sin((entity.age+delta)*.1)*.07,z);matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((entity.age+delta)*3));draw(key,matrices,consumers,light,1,1,1);matrices.pop();return true;
    }
    static void bazooka(Entity player,float delta,MatrixStack matrices,VertexConsumerProvider consumers,int light) {
        if(!CrashAbilities.equipped)return;
        matrices.push();matrices.translate(-.38,1.39,-.12);matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(player.getPitch()));
        matrices.translate(0,0,-CrashExpansion.shotTicks*.012);draw("bazooka",matrices,consumers,light,1,1,1);matrices.pop();
    }
    private static void draw(String key,MatrixStack matrices,VertexConsumerProvider consumers,int light,float red,float green,float blue) {
        Prop prop=props.get(key);if(prop==null)return;var entry=matrices.peek();
        var mc=MinecraftClient.getInstance();
        if(prop.motion!=null)prop.motion.sample(mc.player.getVelocity().horizontalLength()>.04?"run":"idle",(mc.player.age+mc.getRenderTickCounter().getTickDelta(false))/20f);
        var position=new org.joml.Vector3f();var normal=new org.joml.Vector3f();
        for(Mesh mesh:prop.meshes) {
            float[] a=mesh.vertices;
            if(prop.motion!=null) {
                System.arraycopy(a,0,mesh.animated,0,a.length);
                for(int v=0;v<a.length/16;v++) {
                    int base=v*16;Arrays.fill(mesh.animated,base,base+6,0);
                    for(int k=0;k<8;k++) {
                        float weight=a[base+8+k];if(weight<=0)continue;var transform=prop.motion.pose[mesh.joints[v*8+k]];
                        transform.transformPosition(position.set(a[base],a[base+1],a[base+2]));transform.transformDirection(normal.set(a[base+3],a[base+4],a[base+5]));
                        mesh.animated[base]+=position.x*weight;mesh.animated[base+1]+=position.y*weight;mesh.animated[base+2]+=position.z*weight;
                        mesh.animated[base+3]+=normal.x*weight;mesh.animated[base+4]+=normal.y*weight;mesh.animated[base+5]+=normal.z*weight;
                    }
                }
                a=mesh.animated;
            }
            var vc=consumers.getBuffer(RenderLayer.getEntityCutoutNoCull(prop.textures[mesh.material]));
            for(int t=0;t<mesh.indices.length;t+=3)for(int k=0;k<4;k++) {int v=mesh.indices[t+Math.min(k,2)]*16;vc.vertex(entry,a[v],a[v+1],a[v+2]).color(red,green,blue,1f).texture(a[v+6],a[v+7]).overlay(OverlayTexture.DEFAULT_UV).light(light).normal(entry,a[v+3],a[v+4],a[v+5]);}
        }
    }
}

