package dev.crashmc;

import dev.crashmc.generated.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Keeps Minecraft's inventory and world interactions; adds only local solo moves. */
public final class CrashClient implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("crashmc");
    public static volatile boolean enabled = true;
    private static volatile java.util.UUID protectedPlayer;
    public static boolean protectsFromFall(net.minecraft.entity.Entity entity) {
        if (Jump.FALL_DAMAGE || !enabled || protectedPlayer == null || !protectedPlayer.equals(entity.getUuid())) return false;
        var server = entity.getServer();
        return server instanceof net.minecraft.server.integrated.IntegratedServer integrated && !integrated.isRemote();
    }
    public static int spinTicks, cooldownTicks;
    private static KeyBinding spinKey, toggleKey;
    private static boolean jumpHeld, notified;
    private static int airJumps;
    public static int jumpSerial, jumpAge;
    public static boolean isDoubleJump() { return airJumps > 0; }
    private static long nextServerSpin;
    private static Object lastServer;

    public static boolean solo(MinecraftClient mc) {
        return mc.player != null && mc.world != null && mc.getServer() != null
            && !mc.getServer().isRemote() && mc.getServer().getCurrentPlayerCount() == 1;
    }
    public static boolean active() {
        var mc = MinecraftClient.getInstance();
        return enabled && solo(mc) && mc.player.isAlive() && !mc.player.isSpectator() && CrashModel.ready();
    }
    @Override public void onInitializeClient() {
        CrashExpansion.init();
        CrashProps.init();
        spinKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.crashmc.spin", InputUtil.Type.KEYSYM, Controls.SPIN_KEY, Controls.CATEGORY));
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.crashmc.toggle", InputUtil.Type.KEYSYM, Controls.TOGGLE_KEY, Controls.CATEGORY));
        ClientTickEvents.START_CLIENT_TICK.register(CrashClient::tick);
        if (net.fabricmc.loader.api.FabricLoader.getInstance().isDevelopmentEnvironment()) {
            ClientTickEvents.END_CLIENT_TICK.register(CrashVerification::tick);
            ClientTickEvents.END_CLIENT_TICK.register(CrashExpansionVerification::tick);
            ClientTickEvents.END_CLIENT_TICK.register(CrashSlideVerification::tick);
            ClientTickEvents.END_CLIENT_TICK.register(CrashBalanceVerification::tick);
        }
        ClientPlayConnectionEvents.DISCONNECT.register((handler, mc) -> {
            protectedPlayer = null;
            CrashExpansion.reset();
            spinTicks = cooldownTicks = airJumps = 0; jumpHeld = notified = false;
        });
        HudRenderCallback.EVENT.register((ctx, counter) -> {
            var mc = MinecraftClient.getInstance();
            if (!solo(mc) || mc.options.hudHidden || !enabled) return;
            String label = CrashModel.ready()
                ? "CRASH  |  " + spinKey.getBoundKeyLocalizedText().getString() + ": giro " + (cooldownTicks > 0 ? "..." : "listo")
                : "CRASH: falta preparar el modelo — revisa el chat";
            ctx.drawTextWithShadow(mc.textRenderer, label, 8, 8, 0xFFFFB348);
        });
        LOG.info("Crash prototype loaded. Original foundation: Zckyy / Melty. Solo only.");
    }
    private static void tick(MinecraftClient mc) {
        if (!solo(mc)) { CrashExpansion.reset(); protectedPlayer = null; spinTicks = cooldownTicks = airJumps = 0; jumpHeld = false; return; }
        if (mc.isPaused()) return;
        if (!notified) {
            notified = true;
            CrashAudio.prepare(mc);
            CrashModel.load();
            CrashProps.load();
            if (CrashModel.ready()) mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
            if(CrashModel.ready()){}
            else mc.player.sendMessage(Text.literal("No se pudo cargar Crash. Prepara config/crashmc con el conversor. Detalle: "+CrashModel.error()),false);
        }
        while (toggleKey.wasPressed()) if (mc.currentScreen == null) enabled = !enabled;
        protectedPlayer = active() ? mc.player.getUuid() : null;
        CrashExpansion.tick(mc);
        if (spinTicks > 0) spinTicks--;
        if (cooldownTicks > 0) cooldownTicks--;
        boolean jump = mc.options.jumpKey.isPressed();
        if (!active() || mc.currentScreen != null) { jumpHeld = jump; while (spinKey.wasPressed()) {} return; }
        var player = mc.player;
        if (player.isOnGround()) airJumps = 0;
        boolean movementAllowed = !player.hasVehicle() && !player.isTouchingWater() && !player.isInLava()
            && !player.isClimbing() && !player.isGliding() && !player.getAbilities().flying;
        if (jump && !jumpHeld && movementAllowed && (player.isOnGround() || airJumps < Jump.EXTRA_AIR_JUMPS)) {
            if (!player.isOnGround()) {airJumps++;CrashAudio.play(mc,"double_jump");}
            Vec3d velocity = player.getVelocity();
            player.setVelocity(velocity.x, Jump.VELOCITY, velocity.z);
            player.setOnGround(false);
            jumpSerial++; jumpAge = player.age;
        }
        jumpHeld = jump;
        while (spinKey.wasPressed()) {
            if (cooldownTicks != 0 || player.hasVehicle() || CrashAbilities.equipped) continue;
            CrashExpansion.slideTicks=0;
            spinTicks = Spin.DURATION_TICKS; cooldownTicks = Spin.COOLDOWN_TICKS;
            CrashAudio.spin(mc);
            var server = mc.getServer(); var uuid = player.getUuid();
            server.execute(() -> {
                if (server.isRemote() || server.getCurrentPlayerCount() != 1) return;
                if (lastServer != server) { lastServer = server; nextServerSpin = 0; }
                if (server.getTicks() < nextServerSpin) return;
                nextServerSpin = server.getTicks() + Spin.COOLDOWN_TICKS;
                var sp = server.getPlayerManager().getPlayer(uuid);
                if (sp == null || !sp.isAlive() || sp.isSpectator()) return;
                var world = sp.getServerWorld();
                for (var target : world.getEntitiesByClass(LivingEntity.class, sp.getBoundingBox().expand(Spin.RADIUS),
                        e -> !(e instanceof PlayerEntity) && e.isAlive() && sp.squaredDistanceTo(e) <= Spin.RADIUS * Spin.RADIUS && sp.canSee(e))) {
                    if (target.damage(world, world.getDamageSources().playerAttack(sp), (float)Spin.DAMAGE)) {
                        Vec3d away = target.getPos().subtract(sp.getPos()).multiply(1, 0, 1);
                        if (away.lengthSquared() < 0.001) away = sp.getRotationVec(1).multiply(1, 0, 1);
                        away = away.normalize().multiply(Spin.KNOCKBACK);
                        target.setVelocity(away.x, Spin.KNOCKBACK_UP, away.z);
                        target.velocityModified = true;
                    }
                }
                CrashAbilities.spinLeaves(sp);
                world.spawnParticles(ParticleTypes.SWEEP_ATTACK, sp.getX(), sp.getY() + 0.8, sp.getZ(), 6, 0.6, 0.3, 0.6, 0.0);
            });
        }
    }
}
