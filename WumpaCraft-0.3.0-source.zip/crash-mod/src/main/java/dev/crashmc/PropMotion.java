package dev.crashmc;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.GZIPInputStream;
import org.joml.Matrix4f;

final class PropMotion {
    private record Clip(float seconds,Matrix4f[][] frames) {}
    private final Map<String,Clip> clips=new HashMap<>();
    final Matrix4f[] pose;
    PropMotion(Path path,int bones)throws IOException {
        pose=new Matrix4f[bones];for(int i=0;i<bones;i++)pose[i]=new Matrix4f();
        try(var in=new DataInputStream(new BufferedInputStream(new GZIPInputStream(Files.newInputStream(path))))) {
            if(in.readInt()!=0x43524D31||in.readInt()!=bones)throw new IOException("Esqueleto de Aku incompatible");
            int count=in.readInt();if(count<1||count>16)throw new IOException("Clips inválidos");
            for(int c=0;c<count;c++) {
                String key=in.readUTF();int frames=in.readInt();float duration=in.readFloat();
                if(frames<2||frames>1800||!Float.isFinite(duration)||duration<=0)throw new IOException("Duración inválida");
                Matrix4f[][] data=new Matrix4f[frames][bones];float[] values=new float[16];
                for(int f=0;f<frames;f++)for(int j=0;j<bones;j++) {for(int k=0;k<16;k++){values[k]=in.readFloat();if(!Float.isFinite(values[k]))throw new IOException("Pose inválida");}data[f][j]=new Matrix4f().set(values);}
                clips.put(key,new Clip(duration,data));
            }
        }
        if(!clips.containsKey("idle"))throw new IOException("Falta idle de Aku");
    }
    void sample(String key,float time) {
        Clip clip=clips.getOrDefault(key,clips.get("idle"));float frame=(time%clip.seconds)/clip.seconds*(clip.frames.length-1);
        int a=(int)frame,b=Math.min(clip.frames.length-1,a+1);
        for(int i=0;i<pose.length;i++)pose[i].set(clip.frames[a][i]).lerp(clip.frames[b][i],frame-a);
    }
}
