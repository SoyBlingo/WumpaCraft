package dev.crashmc;

import dev.crashmc.generated.Motion;
import dev.crashmc.generated.Spin;
import net.minecraft.entity.Entity;
import org.joml.Matrix4f;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.GZIPInputStream;

/** Sampled tracks from the user's locally installed NST animation archive. */
final class CrashMotion {
    static final Set<String> observedStates = new HashSet<>();
    private record Clip(int frames, float duration, Matrix4f[][] poses) {}
    private static final Map<String, Clip> clips = new HashMap<>();
    private static String state = "";
    private static float started;
    private static int jumpSerial = -1;
    private static Matrix4f[] transition;
    static void load(Path root, int joints) throws IOException {
        Map<String, Clip> next = new HashMap<>();
        try (var in = new DataInputStream(new BufferedInputStream(new GZIPInputStream(Files.newInputStream(root.resolve(Motion.CACHE_FILE)))))) {
            if (in.readInt() != Motion.MAGIC || in.readInt() != joints) throw new IOException("Animación incompatible con el esqueleto");
            int count = in.readInt(); if (count < 1 || count > 32) throw new IOException("Número de animaciones inválido");
            for (int c = 0; c < count; c++) {
                String name = in.readUTF(); int frames = in.readInt(); float duration = in.readFloat();
                if (frames < 2 || frames > 1800 || !Float.isFinite(duration) || duration <= 0) throw new IOException("Duración de animación inválida");
                Matrix4f[][] poses = new Matrix4f[frames][joints]; float[] values = new float[16];
                for (int f = 0; f < frames; f++) for (int j = 0; j < joints; j++) {
                    for (int k = 0; k < 16; k++) { values[k] = in.readFloat(); if (!Float.isFinite(values[k])) throw new IOException("Pose inválida"); }
                    poses[f][j] = new Matrix4f().set(values);
                }
                next.put(name, new Clip(frames, duration, poses));
            }
            if (in.read() != -1) throw new IOException("Datos sobrantes en animaciones");
        }
        for (String required : List.of("idle", "walk", "run", "jump", "double_jump", "fall", "spin", "crouch"))
            if (!next.containsKey(required)) throw new IOException("Falta la animación " + required);
        clips.clear(); clips.putAll(next); state = "";
        CrashClient.LOG.info("Original NST motions loaded: {}", clips.keySet());
    }
    static void pose(Entity player, float delta, Matrix4f[] output) {
        float now = player.age + delta;
        boolean air = !player.isOnGround();
        double speed = player.getVelocity().horizontalLength();
        String next = CrashClient.spinTicks > 0 ? "spin" : air
            ? (CrashClient.isDoubleJump() && now - CrashClient.jumpAge < 13 ? "double_jump" : player.getVelocity().y > 0 ? "jump" : "fall")
            : player.isSneaking() ? "crouch" : speed > .015 ? (player.isSprinting() ? "run" : "walk") : "idle";
        boolean newJump = jumpSerial != CrashClient.jumpSerial;
        if(CrashExpansion.slideTicks>0) next="slide";
        else if(CrashAbilities.equipped) next=CrashExpansion.equipTicks>0?"bazooka_start":CrashExpansion.shotTicks>0?"bazooka_shoot":speed>.015?(player.isSprinting()?"bazooka_run":"bazooka_walk"):player.getPitch() < -20?"bazooka_up":player.getPitch()>20?"bazooka_down":"bazooka_idle";
        else if(CrashExpansion.equipTicks>0) next="bazooka_end";
        if(player.isTouchingWater())next=CrashClient.spinTicks>0?"swim_spin":player.getVelocity().lengthSquared()>.002?"swim":"swim_idle";
        if (!next.equals(state) || newJump || now < started) {
            transition = new Matrix4f[output.length];
            for (int i = 0; i < output.length; i++) transition[i] = new Matrix4f(output[i]);
            state = next; started = now; jumpSerial = CrashClient.jumpSerial;
        }
        Clip clip = clips.get(state);
        observedStates.add(state);
        float elapsed = Math.max(0, now - started) / 20f;
        boolean loop = state.equals("swim") || state.equals("swim_idle") || state.equals("idle") || state.equals("walk") || state.equals("run") || state.equals("fall") || state.equals("crouch") || state.equals("bazooka_idle") || state.equals("bazooka_walk") || state.equals("bazooka_run");
        float progress = loop ? elapsed % clip.duration / clip.duration : Math.min(1, elapsed / clip.duration);
        if (state.equals("spin")) progress = Math.min(1, (Spin.DURATION_TICKS - CrashClient.spinTicks + delta) / (float)Spin.DURATION_TICKS);
        float frame = progress * (clip.frames - 1); int a = Math.min(clip.frames - 1, (int)frame), b = Math.min(clip.frames - 1, a + 1);
        float blend = Math.min(1, (now - started) / (float)Motion.BLEND_TICKS);
        for (int i = 0; i < output.length; i++) {
            output[i].set(clip.poses[a][i]).lerp(clip.poses[b][i], frame - a);
            if (transition != null && blend < 1 && !state.equals("spin")) output[i].lerp(transition[i], 1 - blend);
        }
    }
}
