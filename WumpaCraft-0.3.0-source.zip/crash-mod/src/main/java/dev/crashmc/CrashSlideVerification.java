package dev.crashmc;
import java.nio.file.*;
import java.util.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.block.*;
import net.minecraft.util.math.*;

/** One-shot opt-in slide regression check, with a temporary restored arena. */
final class CrashSlideVerification {
    static int stage=-1,serial;static Vec3d original,start;static float yaw,pitch;static int masks;
    static final Map<BlockPos,BlockState> blocks=new HashMap<>();
    static PigEntity pig;static double maximumSpeed;static boolean activeObserved,stowed;
    static final Map<String,Object> result=new LinkedHashMap<>();
    static final Path root=FabricLoader.getInstance().getConfigDir().resolve("crashmc");
    static void tick(MinecraftClient mc) {
        if(!CrashClient.active()||mc.isPaused()||mc.currentScreen!=null)return;
        if(stage==-2)return;
        if(stage==-1) {
            if(!Files.exists(root.resolve("slide-test.request")))return;
            try{Files.move(root.resolve("slide-test.request"),root.resolve("slide-test.started"),StandardCopyOption.REPLACE_EXISTING);}catch(Exception e){return;}
            original=mc.player.getPos();yaw=mc.player.getYaw();pitch=mc.player.getPitch();masks=CrashAbilities.masks;stage=0;serial=CrashExpansion.slideSerial;
            var id=mc.player.getUuid();mc.getServer().execute(()-> {
                var p=mc.getServer().getPlayerManager().getPlayer(id);var w=p.getServerWorld();BlockPos base=p.getBlockPos().add(0,35,0);
                for(int x=-3;x<=3;x++)for(int z=-3;z<=13;z++) {var b=base.add(x,0,z);blocks.put(b,w.getBlockState(b));w.setBlockState(b,Blocks.STONE.getDefaultState());}
                for(int x=-3;x<=3;x++)for(int y=1;y<=3;y++){var b=base.add(x,y,9);blocks.put(b,w.getBlockState(b));w.setBlockState(b,Blocks.STONE.getDefaultState());}
                start=new Vec3d(base.getX()+.5,base.getY()+1,base.getZ()+.5);p.requestTeleport(start.x,start.y,start.z);p.setYaw(0);p.setPitch(0);
                pig=new PigEntity(EntityType.PIG,w);pig.getAttributeInstance(net.minecraft.entity.attribute.EntityAttributes.MOVEMENT_SPEED).setBaseValue(0);pig.setPosition(start.add(0,0,2));w.spawnEntity(pig);
            });
        }
        stage++;
        if(stage==12){mc.player.setYaw(0);mc.player.setPitch(12);mc.options.setPerspective(net.minecraft.client.option.Perspective.THIRD_PERSON_BACK);}
        if(stage==20){CrashAbilities.equipped=true;CrashExpansion.keyPressed(67,0);}
        if(stage>20&&stage<45){maximumSpeed=Math.max(maximumSpeed,mc.player.getVelocity().horizontalLength());activeObserved|=CrashExpansion.slideTicks>0;stowed|=!CrashAbilities.equipped;}
        if(stage==25||stage==80)net.minecraft.client.util.ScreenshotRecorder.saveScreenshot(mc.runDirectory,"crash-slide-"+stage+".png",mc.getFramebuffer(),t->{});
        if(stage==45) {
            result.put("keyStartsSlide",CrashExpansion.slideSerial>serial);result.put("serverAcceptedSlide",CrashAbilities.acceptedSlides>0);result.put("slideAnimationSelected",CrashMotion.observedStates.contains("slide"));result.put("slideActive",activeObserved);result.put("stowsBazooka",stowed);result.put("maximumHorizontalSpeed",maximumSpeed);result.put("distance",mc.player.getPos().subtract(start).horizontalLength());
            var id=mc.player.getUuid();mc.getServer().execute(()-> {result.put("damage",pig.getMaxHealth()-pig.getHealth());result.put("launchSpeed",CrashAbilities.slideLaunchSpeed);result.put("targetDisplacement",pig.getPos().subtract(start.add(0,0,2)).horizontalLength());pig.discard();CrashAbilities.setMasks(mc.getServer().getPlayerManager().getPlayer(id),2);});
        }
        if(stage==60) {
            var id=mc.player.getUuid();mc.getServer().execute(()-> {
                var p=mc.getServer().getPlayerManager().getPlayer(id);var w=p.getServerWorld();var leaf=p.getBlockPos().add(2,1,0);blocks.put(leaf,w.getBlockState(leaf));w.setBlockState(leaf,Blocks.OAK_LEAVES.getDefaultState());
                result.put("spinBreaksNearbyLeaves",CrashAbilities.spinLeaves(p)>0&&w.getBlockState(leaf).isAir());
                var target=new PigEntity(EntityType.PIG,w);target.setAiDisabled(true);target.setPosition(start.add(0,2,4));w.spawnEntity(target);
                CrashAbilities.explode(p,start.add(0,2.5,3));result.put("explosionAreaDamage",target.getMaxHealth()-target.getHealth());target.discard();
                for(var item:w.getEntitiesByClass(net.minecraft.entity.ItemEntity.class,new Box(start.add(-4,0,-4),start.add(4,5,14)),e->true))item.discard();
            });
        }
        if(stage==100) {
            var id=mc.player.getUuid();mc.getServer().execute(()->{var p=mc.getServer().getPlayerManager().getPlayer(id);for(var e:blocks.entrySet())p.getServerWorld().setBlockState(e.getKey(),e.getValue());p.requestTeleport(original.x,original.y,original.z);CrashAbilities.setMasks(p,masks);try{Files.writeString(root.resolve("slide-test.json"),new com.google.gson.GsonBuilder().setPrettyPrinting().create().toJson(result));}catch(Exception ex){CrashClient.LOG.error("Slide verification",ex);}CrashClient.LOG.info("CRASH_SLIDE_VERIFY {}",result);});
            mc.player.setYaw(yaw);mc.player.setPitch(pitch);stage=-2;
        }
    }
}
