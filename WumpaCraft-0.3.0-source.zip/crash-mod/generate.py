"""Validate every sheet cell/reference, then emit one Java class per sheet row."""
from pathlib import Path
import json,re,sys
root=Path(__file__).resolve().parent
rows=json.loads((root/'design/systems.json').read_text());ids={r['id'] for r in rows};errors=[]
for i,row in enumerate(rows):
 for column in ('id','references','evidence','values'):
  if column not in row or row[column] is None or row[column]=='':errors.append(f'row {i}: empty {column}')
 for key,val in row.get('values',{}).items():
  if val is None or val=='':errors.append(f'{row["id"]}.{key}: empty cell')
  if not re.fullmatch('[A-Z][A-Z0-9_]*',key):errors.append(f'invalid column {key}')
 for ref in row.get('references',[]):
  if ref not in ids:errors.append(f'{row["id"]}: unresolved {ref}')
if len(ids)!=len(rows):errors.append('Duplicate row ID')
if errors:print('\n'.join(errors));sys.exit(1)
dest=root/'src/main/java/dev/crashmc/generated';dest.mkdir(parents=True,exist_ok=True)
for row in rows:
 lines=['package dev.crashmc.generated;','// Generated from design/systems.json. Edit the sheet first.',f'public final class {row["id"]} {{']
 for key,value in row['values'].items():
  typ='boolean' if isinstance(value,bool) else 'int' if isinstance(value,int) else 'double' if isinstance(value,float) else 'String'
  lines.append(f'    public static final {typ} {key} = {json.dumps(value)};')
 lines.append('}')
 (dest/(row['id']+'.java')).write_text('\n'.join(lines)+'\n')
print(f'Preflight OK: {len(rows)} rows, {sum(len(r["values"]) for r in rows)} populated values, all references resolve. Runtime verification remains separate.')
