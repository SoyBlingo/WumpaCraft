"""Read-only NST PAK extraction. Format based on Kishimisu's MIT PAK parser.
Outputs exclusively under work/crash-assets; game archives never written.
"""
from pathlib import Path
import struct,json,zlib,lzma

class Pak:
 def __init__(self,path):
  self.data=Path(path).read_bytes();d=self.data
  u=lambda at:struct.unpack_from('<I',d,at)[0]
  assert u(0)==0x1A414749
  self.count=u(12);self.sector=u(16);names=u(40);offset=56+self.count*20
  self.tables=[]
  for fmt,count in zip(('I','H','B'),(u(28),u(32),u(36))):
   self.tables.append(list(struct.unpack_from('<'+fmt*count,d,offset)));offset+=struct.calcsize(fmt)*count
  self.files=[]
  for i in range(self.count):
   off,ordinal,size,comp=struct.unpack_from('<IIII',d,56+self.count*4+i*16)
   pos=names+u(names+i*4);end=d.index(0,pos);pos=end+1;end=d.index(0,pos)
   self.files.append(dict(path=d[pos:end].decode(),offset=off,size=size,compression=comp))
 def extract(self,file):
  d=self.data;off=file['offset'];size=file['size'];comp=file['compression']
  if comp==0xffffffff:return d[off:off+size]
  table,mask,shift=(self.tables[2],127,7) if size<=127*self.sector else ((self.tables[1],32767,15) if size<=32767*self.sector else (self.tables[0],0x7fffffff,31))
  result=bytearray()
  for block in range((size+32767)//32768):
   info=table[(comp&0xfffffff)+block];src=off+(info&mask)*self.sector;count=min(32768,size-len(result));kind=(comp>>28) if info>>shift else 0
   if kind==0:chunk=d[src:src+count]
   else:
    length=struct.unpack_from('<H',d,src)[0]
    if kind==1:chunk=zlib.decompress(d[src+2:src+2+length],-15)
    elif kind==2:chunk=lzma.decompress(d[src+2:src+7]+struct.pack('<Q',count)+d[src+7:src+7+length],format=lzma.FORMAT_ALONE)
    else:raise ValueError('Unsupported compression '+str(kind))
   assert len(chunk)>=count
   result.extend(chunk[:count])
  assert len(result)==size
  return bytes(result)


