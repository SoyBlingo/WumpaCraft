"""Rasterize owned-game meshes into inventory icons and inspection previews."""
from pathlib import Path
import json,struct,numpy as np,zipfile
from PIL import Image
p=Path('work/crash-cache/props'); icons={}
for key in ['wumpa','aku','bazooka']:
 meta=json.loads((p/(key+'.json')).read_text());textures=[np.array(Image.open(p/m['texture']).convert('RGBA')) for m in meta['materials']]
 b=(p/(key+'.bin')).read_bytes();at=8;meshes=[]
 for k in range(struct.unpack_from('>I',b,4)[0]):
  mat,n,ni=struct.unpack_from('>III',b,at);at+=12;v=np.frombuffer(b,dtype='>f4',count=n*24,offset=at).reshape(n,24).astype(float);at+=n*96;ids=np.frombuffer(b,dtype='>u4',count=ni,offset=at).reshape(-1,3);at+=ni*4;meshes.append((mat,v,ids))
 W=384;H=384;out=np.zeros((H,W,4),dtype=np.uint8);depth=np.full((H,W),-np.inf)
 angle=1.0 if key=='bazooka' else .12;c=np.cos(angle);s=np.sin(angle);rot=np.array([[c,0,s],[0,1,0],[-s,0,c]])
 allpos=np.concatenate([v[:,:3]@rot.T for _,v,_ in meshes]);lo=allpos.min(axis=0);hi=allpos.max(axis=0);center=(lo+hi)/2;scale=340/max(hi[:2]-lo[:2])
 for mat,v,tri in meshes:
  pos=v[:,:3]@rot.T-center;xy=np.stack((W/2+pos[:,0]*scale,H/2-pos[:,1]*scale),axis=1);z=pos[:,2];tex=textures[mat]
  for inds in tri:
   q=xy[inds];low=np.maximum(np.floor(q.min(axis=0)).astype(int),0);high=np.minimum(np.ceil(q.max(axis=0)).astype(int),[W-1,H-1])
   if np.any(high<low):continue
   den=(q[1,1]-q[2,1])*(q[0,0]-q[2,0])+(q[2,0]-q[1,0])*(q[0,1]-q[2,1])
   if abs(den)<1e-7:continue
   ys,xs=np.mgrid[low[1]:high[1]+1,low[0]:high[0]+1];a=((q[1,1]-q[2,1])*(xs-q[2,0])+(q[2,0]-q[1,0])*(ys-q[2,1]))/den;bb=((q[2,1]-q[0,1])*(xs-q[2,0])+(q[0,0]-q[2,0])*(ys-q[2,1]))/den;cc=1-a-bb
   inside=(a>=0)&(bb>=0)&(cc>=0);zz=a*z[inds[0]]+bb*z[inds[1]]+cc*z[inds[2]];d=depth[low[1]:high[1]+1,low[0]:high[0]+1];inside&=zz>d
   uv=a[:,:,None]*v[inds[0],6:8]+bb[:,:,None]*v[inds[1],6:8]+cc[:,:,None]*v[inds[2],6:8];rgba=tex[(uv[:,:,1]*tex.shape[0]).astype(int)%tex.shape[0],(uv[:,:,0]*tex.shape[1]).astype(int)%tex.shape[1]];inside&=rgba[:,:,3]>100
   dest=out[low[1]:high[1]+1,low[0]:high[0]+1];dest[inside]=rgba[inside];d[inside]=zz[inside]
 image=Image.fromarray(out);image.save(p/(key+'_preview.png'));image.resize((64,64),Image.Resampling.LANCZOS).save(p/(key+'_icon.png'));icons[key]=p/(key+'_icon.png')
pack=Path('work/crash-cache/crashmc-local-audio.zip')
with zipfile.ZipFile(pack) as z:contents={n:z.read(n) for n in z.namelist()}
for key,name in [('wumpa','wumpa'),('aku','aku_aku')]:contents['assets/crashmc/textures/item/'+name+'.png']=icons[key].read_bytes()
with zipfile.ZipFile(pack,'w',zipfile.ZIP_DEFLATED) as z:
 for n,data in contents.items():z.writestr(n,data)
print('Rendered icons from original meshes')
