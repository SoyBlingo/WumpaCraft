from pathlib import Path
import sys,json,zipfile
root=Path('work/crash-expansion')
sys.path.insert(0,str(Path('work/audio-python').resolve()));import soundfile as sf
pack=Path('work/crash-cache/crashmc-local-audio.zip')
with zipfile.ZipFile(pack) as z:contents={n:z.read(n) for n in z.namelist()}
sounds=json.loads(contents['assets/crashmc/sounds.json'])
mapping={'double_jump':'CHAMP_CB_FootV2_Jump_Flip_01','slide':'fx_coco_slideattack_01','bazooka_equip':'fx_bazooka_equip_01','bazooka_shoot':'fx_bazooka_shoot_01','bazooka_impact':'fx_bazooka_shoot_impact_01','wumpa_collect':'com_wumpa_collect_01','aku_one':'com_aku_reveal_L1_01','aku_two':'com_aku_reveal_L2_01','aku_lose':'com_aku_lose_01','aku_end':'fx_Aku3_fail_01','aku_power':'com_aku_InvinciRun_01'}
for key,source in mapping.items():
 samples,rate=sf.read(root/'audio'/(source+'.wav'));cap={'slide':.6,'double_jump':.5,'bazooka_shoot':.5,'aku_power':20}.get(key)
 if cap and len(samples)>int(cap*rate):
  import numpy as np
  samples=samples[:int(cap*rate)].copy();fade=min(len(samples),int(.025*rate));env=np.linspace(1,0,fade);samples[-fade:]*=env[:,None] if samples.ndim>1 else env
 target=root/'audio'/(key+'.ogg')
 with sf.SoundFile(target,'w',samplerate=rate,channels=1 if samples.ndim==1 else samples.shape[1],format='OGG',subtype='VORBIS') as dst:
  for start in range(0,len(samples),4096):dst.write(samples[start:start+4096])
 contents['assets/crashmc/sounds/'+key+'.ogg']=target.read_bytes();sounds[key]={'sounds':[{'name':'crashmc:'+key,'stream':key=='aku_power'}]}
 print('Encoded',key,len(samples)/rate,flush=True)
contents['assets/crashmc/sounds.json']=json.dumps(sounds).encode()
with zipfile.ZipFile(pack,'w',zipfile.ZIP_DEFLATED) as z:
 for name,data in contents.items():z.writestr(name,data)
print('Local props and sound pack prepared')
