"""Read-only IGZ inspector, based on Kishimisu's MIT format documentation/code."""
from pathlib import Path
import struct,json,sys,bisect
class IGZ:
 def u(self,p):return struct.unpack_from('<I',self.d,p)[0]
 def addr(self,p):return self.chunks[(p>>27)+1][0]+(p&0x7ffffff)
 def __init__(self,data):
  self.d=data;assert self.u(0)==0x49475a01 and self.u(4)==10
  self.chunks=[]
  for p in range(16,2048,16):
   off,size=struct.unpack_from('<II',data,p+8)
   if not off:break
   self.chunks.append((off,size))
  self.fix={};p=self.chunks[0][0];end=p+self.chunks[0][1]
  while p+16<=end:
   typ=data[p:p+4].decode('ascii');count,size,head=struct.unpack_from('<III',data,p+4)
   if not size:break
   b=data[p+head:p+size];v=[]
   if typ.startswith('R') and typ!='ROOT':
    cur=shift=last=0
    for byte in b:
     for n in (byte&15,byte>>4):
      cur|=(n&7)<<shift;shift+=3
      if not n&8:
       last+=cur*4;v.append(last);cur=shift=0
      if len(v)>=count:break
     if len(v)>=count:break
   elif typ in ('TDEP','TSTR','TMET'):
    j=0
    while j<len(b) and len(v)<count*(2 if typ=='TDEP' else 1):
     k=b.index(0,j);v.append(b[j:k].decode());j=k+1
     if j<len(b) and b[j]==0:j+=1
   else:
    v=list(struct.unpack_from('<'+'I'*(count*(2 if typ in ('EXID','EXNM') else 1)),b))
    if typ in ('EXID','EXNM'):v=list(zip(v[::2],v[1::2]))
   self.fix[typ]=v;p+=size
  self.handles=[(self.fix['TSTR'][a],self.fix['TSTR'][b&0x7fffffff]) for a,b in self.fix.get('EXNM',[]) if b&0x80000000]
  self.objects=[]
  for ref in self.fix['RVTB']:
   at=self.addr(ref);self.objects.append(dict(ref=ref,at=at,type=self.fix['TMET'][self.u(at)],name=''))
  self.byref={o['ref']:o for o in self.objects};self.offsets=[o['at'] for o in self.objects]
  for i,o in enumerate(self.objects):o['end']=self.objects[i+1]['at'] if i+1<len(self.objects) else sum(self.chunks[-1])
  names=next((o for o in self.objects if o['type']=='igNameList'),None)
  if names:
   for ptr,name in zip(self.list(self.objects[0]),self.list(names)):
    if ptr in self.byref:self.byref[ptr]['name']=self.fix['TSTR'][name]
  for o in self.objects:o['children']=[]
  for ref in self.fix.get('ROFS',[]):
   p=self.addr(ref);idx=bisect.bisect_right(self.offsets,p)-1
   target=self.byref.get(self.u(p))
   if idx>=0 and target and target['ref'] not in self.objects[idx]['children']:self.objects[idx]['children'].append(target['ref'])
 def list(self,o):
  at=o['at'];n=self.u(at+16);size=self.u(at+24)
  return [self.u(at+40+i*(size//n)) for i in range(n)]
 def child(self,o,typ):return next(self.byref[r] for r in o['children'] if self.byref[r]['type']==typ)
 def mem(self,o,off,stride=4):
  at=o['at']+off;size=self.u(at)
  return [self.u(self.addr(self.u(at+8))+i) for i in range(0,size,stride)] if size else []
 def tree(self,o,seen=None):
  seen=set() if seen is None else seen
  if o['ref'] in seen:return []
  seen.add(o['ref']);return [o]+[x for r in o['children'] for x in self.tree(self.byref[r],seen)]
if __name__=='__main__':
 g=IGZ(Path(sys.argv[1]).read_bytes())
 print('chunks',g.chunks,'objects',len(g.objects),'handles',g.handles)
 for o in g.objects:
  if o['type'] in ('igModelData','igModelDrawCallData','igVertexBuffer','igIndexBuffer','igVertexFormat','igSkeleton','igSkeletonBone','igImage2'):
   print(o, 'data',g.d[o['at']+16:min(o['end'],o['at']+120)].hex(' '))
