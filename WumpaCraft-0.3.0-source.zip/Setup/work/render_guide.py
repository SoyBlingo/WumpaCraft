"""Offline model inspection, not a Minecraft screenshot or publication media."""
from pathlib import Path
import json,struct,numpy as np,sys,gzip
from PIL import Image
p=Path('work/crash-cache');meta=json.loads((p/'model.json').read_text());textures=[np.array(Image.open(p/m['texture']).convert('RGBA')) for m in meta['materials']]
b=(p/'model.bin').read_bytes();at=8;meshes=[]
for k in range(meta['meshCount']):
 mat,n,ni=struct.unpack_from('>III',b,at);at+=12
 v=np.frombuffer(b,dtype='>f4',count=n*24,offset=at).reshape(n,24).astype(float);at+=n*96
 bones=np.frombuffer(b,dtype='>u4',count=n*24,offset=at-n*96).reshape(n,24)[:,16:24].copy()
 ids=np.frombuffer(b,dtype='>u4',count=ni,offset=at).reshape(-1,3);at+=ni*4;meshes.append((mat,v,ids,bones))
if len(sys.argv)>1:
 with gzip.open(p/'motion.bin.gz','rb') as f:
  magic,joints,clips=struct.unpack('>iii',f.read(12))
  for _ in range(clips):
   key=f.read(struct.unpack('>H',f.read(2))[0]).decode();frames,duration=struct.unpack('>if',f.read(8));data=np.frombuffer(f.read(frames*joints*64),dtype='>f4').reshape(frames,joints,4,4).transpose(0,1,3,2)
   if key==sys.argv[1]:trans=data[int(float(sys.argv[2])* (frames-1))]
 for mat,v,tri,bones in meshes:
  pos=np.c_[v[:,:3],np.ones(len(v))];normal=np.c_[v[:,3:6],np.zeros(len(v))]
  v[:,:3]=sum(np.einsum('nij,nj->ni',trans[bones[:,k]],pos)[:,:3]*v[:,8+k,None] for k in range(8))
  v[:,3:6]=sum(np.einsum('nij,nj->ni',trans[bones[:,k]],normal)[:,:3]*v[:,8+k,None] for k in range(8))
W=800;H=800;out=np.zeros((H,W,4),dtype=np.uint8);depth=np.full((H,W),-np.inf)
angle=.35;c=np.cos(angle);s=np.sin(angle);rot=np.array([[c,0,s],[0,1,0],[-s,0,c]])
for mat,v,tri,bones in meshes:
 pos=v[:,:3]@rot.T;xy=np.stack((400+pos[:,0]*330,735-pos[:,1]*330),axis=1);z=pos[:,2];tex=textures[mat];light=np.array([-.3,.5,1]);light/=np.linalg.norm(light)
 for inds in tri:
  q=xy[inds];lo=np.maximum(np.floor(q.min(axis=0)).astype(int),0);hi=np.minimum(np.ceil(q.max(axis=0)).astype(int),[W-1,H-1])
  if np.any(hi<lo):continue
  den=(q[1,1]-q[2,1])*(q[0,0]-q[2,0])+(q[2,0]-q[1,0])*(q[0,1]-q[2,1])
  if abs(den)<1e-7:continue
  ys,xs=np.mgrid[lo[1]:hi[1]+1,lo[0]:hi[0]+1];a=((q[1,1]-q[2,1])*(xs-q[2,0])+(q[2,0]-q[1,0])*(ys-q[2,1]))/den;bary=((q[2,1]-q[0,1])*(xs-q[2,0])+(q[0,0]-q[2,0])*(ys-q[2,1]))/den;cc=1-a-bary
  inside=(a>=0)&(bary>=0)&(cc>=0);zz=a*z[inds[0]]+bary*z[inds[1]]+cc*z[inds[2]];d=depth[lo[1]:hi[1]+1,lo[0]:hi[0]+1];inside&=zz>d
  uv=a[:,:,None]*v[inds[0],6:8]+bary[:,:,None]*v[inds[1],6:8]+cc[:,:,None]*v[inds[2],6:8];tx=(uv[:,:,0]*tex.shape[1]).astype(int)%tex.shape[1];ty=(uv[:,:,1]*tex.shape[0]).astype(int)%tex.shape[0];rgba=tex[ty,tx];inside&=rgba[:,:,3]>100
  shade=.5+.5*abs(np.dot(np.mean(v[inds,3:6],axis=0)@rot.T,light));rgb=(rgba[:,:,:3]*shade).clip(0,255).astype(np.uint8)
  dest=out[lo[1]:hi[1]+1,lo[0]:hi[0]+1];dest[inside,:3]=rgb[inside];dest[inside,3]=255;d[inside]=zz[inside]
Image.fromarray(out).save('work/crash-guide.png');print('Offline preview saved')
