from pathlib import Path
import json,struct,gzip,numpy as np
from convert_motion import GLB,globals_for
r=Path('work/crash-cache/props');info=json.loads((r/'aku.json').read_text());g=GLB('work/motion-tools/havok/AkuAku.glb');nodes=g.g['nodes'];rest=globals_for(nodes);lookup={n.get('name'):i for i,n in enumerate(nodes) if n.get('name')}
pairs=[(j,lookup[j['name']]) for j in info['joints'] if j['name'] in lookup];x=np.array([np.r_[rest[i][:3,3],1] for j,i in pairs]);y=np.array([j['pivot'] for j,i in pairs]);C=np.eye(4);C[:3]=np.linalg.lstsq(x,y,rcond=None)[0].T;error=np.max(np.linalg.norm((C@x.T).T[:,:3]-y,axis=1));print('Bind error',error);assert error<.005
invC=np.linalg.inv(C);invrest=np.linalg.inv(rest);clips={'idle':8,'run':6,'spawn':3};output={}
with gzip.open(r/'aku-motion.bin.gz','wb') as f:
 f.write(struct.pack('>iii',0x43524d31,len(info['joints']),len(clips)))
 for key,index in clips.items():
  a=g.g['animations'][index];tracks={}
  for ch in a['channels']:
   target=ch['target']['node']+2
   if target>=len(nodes):continue
   sampler=a['samplers'][ch['sampler']];tracks[target,ch['target']['path']]=(g.accessor(sampler['input'])[:,0],g.accessor(sampler['output']))
  duration=max(.1,max(ts[-1] for ts,vs in tracks.values()));frames=int(np.ceil(duration*30))+1
  f.write(struct.pack('>H',len(key))+key.encode()+struct.pack('>if',frames,duration));sample=[]
  if key=='idle':
   root=lookup['Bone_Root'];reference=globals_for(nodes,tracks,0)[root];pre=rest[root]@np.linalg.inv(reference)
  for t in np.linspace(0,duration,frames):
   world=pre@globals_for(nodes,tracks,t)
   mats=np.array([np.eye(4) if j['name'] not in lookup else C@world[lookup[j['name']]]@invrest[lookup[j['name']]]@invC for j in info['joints']]);assert np.isfinite(mats).all();sample.append(mats);f.write(mats.transpose(0,2,1).astype('>f4').tobytes())
  output[key]=dict(duration=float(duration),frames=frames);np.save(r/('aku-'+key+'.npy'),np.array(sample));print(key,output[key])
(r/'aku-motion.json').write_text(json.dumps(output,indent=2))

