from pathlib import Path
import json,struct,shutil,sys,zipfile
from inspect_igz import IGZ
from convert_crash import inv,coords
root=Path('work/crash-expansion');originals=root/'originals';out=Path('work/crash-cache/props');out.mkdir(exist_ok=True)
manifest=json.loads((root/'prepared-manifest.json').read_text())['files']
by_stem={Path(f['path']).stem.lower():f for f in manifest}

def convert(key,path,length):
 g=IGZ((originals/path).read_bytes()); materials=[]
 for name,ref in g.handles:
  mat=IGZ((originals/by_stem[ref.lower()]['path']).read_bytes());obj=next(o for o in mat.objects if o['name']==name)
  refs=[mat.handles[mat.u(o['at']+80)&0x7fffffff][1] for o in mat.tree(obj) if o['type']=='igTextureAttr2']
  diffuse=next((n for n in refs if n.startswith('ColorMap') and '_C`' in n),next((n for n in refs if n.startswith('ColorMap')),None))
  if diffuse is None:
   materials.append(materials[0] if materials else '');continue
  png=by_stem[diffuse.lower()]['preview'];name=key+'_'+str(len(materials))+'.png';shutil.copyfile(png,out/name);materials.append(name)
 skeleton=next((o for o in g.objects if o['type']=='igSkeleton2'),None);joints=[]
 if skeleton:
  base=g.addr(g.u(skeleton['at']+40))
  for o in (g.byref[r] for r in g.list(g.child(skeleton,'igSkeletonBoneList'))):
   parent,index=struct.unpack_from('<ii',g.d,o['at']+24);m=inv(struct.unpack_from('<16f',g.d,base+index*64)) if index>=0 else [1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]
   joints.append(dict(name=g.fix['TSTR'][g.u(o['at']+16)],parent=parent,pivot=coords(m[12:15])))
 else:joints=[dict(name='root',parent=-1,pivot=[0,0,0])]
 model=next(o for o in g.objects if o['type']=='igModelData');palette=g.mem(model,192);meshes=[];positions=[]
 for obj in (g.byref[r] for r in g.mem(model,120,8)):
  vb=g.child(g.child(obj,'igGraphicsVertexBuffer'),'igVertexBuffer');fmt=g.child(vb,'igVertexFormat');ib=g.child(g.child(obj,'igGraphicsIndexBuffer'),'igIndexBuffer')
  stride=g.u(fmt['at']+16);p=g.addr(g.u(vb['at']+48));n=g.u(vb['at']+16);ep=g.addr(g.u(fmt['at']+32))
  els=[struct.unpack_from('<8B2H',g.d,a) for a in range(ep,ep+g.u(fmt['at']+24),12)];fields={(e[4],e[5]):e[8] for e in els if e[0]!=44}
  offset,count=struct.unpack_from('<HH',g.d,obj['at']+96);pal=palette[offset:offset+count];vertices=[]
  for i in range(n):
   at=p+i*stride;pos=coords(struct.unpack_from('<3f',g.d,at));normal=coords(struct.unpack_from('<3f',g.d,at+12));uv=struct.unpack_from('<2e',g.d,at+fields[(5,0)])
   weights=[];ids=[]
   for channel in (0,1):
    if (6,channel) in fields:
     weights+=list(g.d[at+fields[(6,channel)]:at+fields[(6,channel)]+4]);ids+=list(struct.unpack_from('<4I',g.d,at+fields[(8,channel)]))
   if not weights:weights=[255];ids=[0]
   total=sum(weights);js=[pal[j]+1 if w and pal else 0 for j,w in zip(ids,weights)];ws=[w/total for w in weights]
   ws+= [0]*(8-len(ws));js+=[0]*(8-len(js));vertices.append((pos+normal+list(uv)+ws,js));positions.append(pos)
  ip=g.addr(g.u(ib['at']+48));indices=struct.unpack_from('<'+'H'*g.u(ib['at']+16),g.d,ip);assert max(indices)<n
  meshes.append((g.u(obj['at']+64)&0x7fffffff,vertices,indices))
 lo=[min(v[i] for v in positions) for i in range(3)];hi=[max(v[i] for v in positions) for i in range(3)];scale=length/max(h-l for h,l in zip(hi,lo));center=[(h+l)/2 for h,l in zip(hi,lo)]
 for j in joints:j['pivot']=[(v-c)*scale for v,c in zip(j['pivot'],center)]
 info=dict(format=1,materials=[dict(texture=m) for m in materials],joints=joints,scale=scale,center=center,bounds=[lo,hi])
 (out/(key+'.json')).write_text(json.dumps(info,indent=2))
 with (out/(key+'.bin')).open('wb') as f:
  f.write(struct.pack('>II',0x43524153,len(meshes)))
  for material,vs,indices in meshes:
   f.write(struct.pack('>III',material,len(vs),len(indices)))
   for v,js in vs:v[:3]=[(x-c)*scale for x,c in zip(v[:3],center)];f.write(struct.pack('>16f8I',*v,*js))
   f.write(struct.pack('>'+'I'*len(indices),*indices))
 print(key,'meshes',len(meshes),'bones',len(joints),'bounds',lo,hi,flush=True)

convert('bazooka','actors/Playable/Props/Crash_Bazooka_Skinned.igz',1.05)
convert('aku','actors/NPC/AkuAku.igz',.7)
convert('wumpa','models/Levels/Crash1/collectibles/crash_wumpafruit_no_sparkles.igz',.3)

