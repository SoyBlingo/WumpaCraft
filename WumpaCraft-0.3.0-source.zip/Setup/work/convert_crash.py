"""Convert only the owned NST Crash actor to a local Minecraft render cache.
Never distribute the cache. Format research: Kishimisu/The Apprentice (MIT).
"""
import argparse,io,json,math,struct
from pathlib import Path
from read_crash_pak import Pak
from inspect_igz import IGZ
from PIL import Image

def hash_name(s):
 h=0x811c9dc5
 for c in s.lower():h=((h^ord(c))*16777619)&0xffffffff
 return h
def inv(a):
 m=[list(a[r*4:r*4+4])+[float(r==c) for c in range(4)] for r in range(4)]
 for c in range(4):
  j=max(range(c,4),key=lambda r:abs(m[r][c]));m[c],m[j]=m[j],m[c]
  f=m[c][c];assert abs(f)>1e-10;m[c]=[v/f for v in m[c]]
  for r in range(4):
   if r!=c:
    f=m[r][c];m[r]=[v-f*w for v,w in zip(m[r],m[c])]
 return [v for row in m for v in row[4:]]
def coords(v):return [v[1],v[2],v[0]]
def texture(pak,name,target):
 f=next(f for f in pak.files if Path(f['path']).stem.lower()==name.lower())
 g=IGZ(pak.extract(f));o=next(o for o in g.objects if o['type']=='igImage2');at=o['at']
 w,h=struct.unpack_from('<HH',g.d,at+24);size=g.u(at+56);p=g.addr(g.u(at+64));raw=g.d[p:p+size]
 formats={hash_name('dxt1_dx11'):b'DXT1',hash_name('dxt5_dx11'):b'DXT5'}
 fmt=formats[g.fix['EXID'][0][0]]
 header=bytearray(128);header[:4]=b'DDS ';struct.pack_into('<7I',header,4,124,0x81007,h,w,len(raw),0,1)
 struct.pack_into('<II4s',header,76,32,4,fmt);struct.pack_into('<I',header,108,0x1000)
 image=Image.open(io.BytesIO(header+raw)).convert('RGBA');image.save(target)
 return [w,h]
def convert(archive,output):
 pak=Pak(archive);output.mkdir(parents=True,exist_ok=True)
 f=next(f for f in pak.files if f['path'].lower()=='actors/playable/crash.igz');g=IGZ(pak.extract(f))
 material=next(f for f in pak.files if Path(f['path']).stem=='Crash_materials,Crash,01557');mat=IGZ(pak.extract(material))
 mats=[]
 for name,_ in g.handles:
  o=next(o for o in mat.objects if o['name']==name);children=mat.tree(o)
  names=[mat.handles[mat.u(o['at']+80)&0x7fffffff][1] for o in children if o['type']=='igTextureAttr2']
  names=[n for n in names if n.startswith('ColorMap') and '_C`' in n]
  assert names,name
  filename=name.lower()+'.png';dims=texture(pak,names[0],output/filename)
  color=next((struct.unpack_from('<4f',mat.d,o['at']+32) for o in children if o['type']=='igColorAttr'),(1,1,1,1))
  mats.append(dict(name=name,texture=filename,size=dims,color=color))
 skeleton=next(o for o in g.objects if o['type']=='igSkeleton2');bones=[g.byref[r] for r in g.list(g.child(skeleton,'igSkeletonBoneList'))]
 matrix_start=g.addr(g.u(skeleton['at']+40));count=g.u(skeleton['at']+32)//64
 assert count==len(bones)-1
 joints=[]
 for i,o in enumerate(bones):
  parent,index=struct.unpack_from('<ii',g.d,o['at']+24)
  rest=inv(struct.unpack_from('<16f',g.d,matrix_start+index*64)) if index>=0 else [1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]
  joints.append(dict(name=g.fix['TSTR'][g.u(o['at']+16)],parent=parent,pivot=coords(rest[12:15])))
 model=next(o for o in g.objects if o['type']=='igModelData');palette=g.mem(model,192)
 meshes=[];allpos=[]
 for o in (g.byref[r] for r in g.mem(model,120,8)):
  vb=g.child(g.child(o,'igGraphicsVertexBuffer'),'igVertexBuffer');fmt=g.child(vb,'igVertexFormat');ib=g.child(g.child(o,'igGraphicsIndexBuffer'),'igIndexBuffer')
  stride=g.u(fmt['at']+16);p=g.addr(g.u(vb['at']+48));n=g.u(vb['at']+16)
  ep=g.addr(g.u(fmt['at']+32));els=[struct.unpack_from('<8B2H',g.d,a) for a in range(ep,ep+g.u(fmt['at']+24),12)]
  fields={(e[4],e[5]):e[8] for e in els if e[0]!=44}
  offset,count=struct.unpack_from('<HH',g.d,o['at']+96);pal=palette[offset:offset+count];verts=[]
  for i in range(n):
   at=p+i*stride;pos=coords(struct.unpack_from('<3f',g.d,at));normal=coords(struct.unpack_from('<3f',g.d,at+12));uv=struct.unpack_from('<2e',g.d,at+fields[(5,0)])
   weights=list(g.d[at+fields[(6,0)]:at+fields[(6,0)]+4])+list(g.d[at+fields[(6,1)]:at+fields[(6,1)]+4])
   ids=list(struct.unpack_from('<4I',g.d,at+fields[(8,0)]))+list(struct.unpack_from('<4I',g.d,at+fields[(8,1)]))
   total=sum(weights);assert total>0
   jointids=[pal[j]+1 if weight else 0 for j,weight in zip(ids,weights)]
   assert all(0<=j<len(joints) for j in jointids)
   v=pos+normal+list(uv)+[v/total for v in weights];assert all(math.isfinite(x) for x in v)
   verts.append((v,jointids));allpos.append(pos)
  ip=g.addr(g.u(ib['at']+48));indices=struct.unpack_from('<'+'H'*g.u(ib['at']+16),g.d,ip)
  assert len(indices)%3==0 and max(indices)<n
  meshes.append((g.u(o['at']+64)&0x7fffffff,verts,indices))
 lo=[min(v[i] for v in allpos) for i in range(3)];hi=[max(v[i] for v in allpos) for i in range(3)]
 scale=1.8/(hi[1]-lo[1]);center=[(hi[0]+lo[0])/2,lo[1],(hi[2]+lo[2])/2]
 for j in joints:j['pivot']=[(x-c)*scale for x,c in zip(j['pivot'],center)]
 metadata=dict(format=1,source='Owned Crash N. Sane Trilogy / Crash.pak',materials=mats,joints=joints,meshCount=len(meshes),vertices=sum(len(m[1]) for m in meshes),triangles=sum(len(m[2])//3 for m in meshes),bounds=[lo,hi],scale=scale)
 (output/'model.json').write_text(json.dumps(metadata,indent=2),encoding='utf8')
 with (output/'model.bin').open('wb') as out:
  out.write(struct.pack('>II',0x43524153,len(meshes)))
  for material,vertices,indices in meshes:
   out.write(struct.pack('>III',material,len(vertices),len(indices)))
   for v,ids in vertices:
    v[:3]=[(x-c)*scale for x,c in zip(v[:3],center)];out.write(struct.pack('>16f8I',*v,*ids))
   out.write(struct.pack('>'+'I'*len(indices),*indices))
 print(json.dumps({k:metadata[k] for k in ('meshCount','vertices','triangles','scale')}))
 print('Local cache:',output.resolve())
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('output',type=Path);a=p.parse_args();convert(a.archive,a.output)
