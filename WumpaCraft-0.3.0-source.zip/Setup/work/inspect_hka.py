import struct,json
from pathlib import Path
class HKA:
 def __init__(self,path):
  self.d=Path(path).read_bytes();d=self.d;self.p={};self.types={}
  self.i=lambda p:struct.unpack_from('<i',d,p)[0]
  self.s=lambda p:d[p:d.index(b'\0',p)].decode()
  self.sections=[struct.unpack_from('<7i',d,80+n*64+20) for n in range(self.i(20))]
  for base,local,glob,virt,exp,imp,size in self.sections:
   for at in range(base+local,base+glob-7,8):
    a,b=struct.unpack_from('<2i',d,at)
    if a>=0:self.p[base+a]=base+b
   for at in range(base+glob,base+virt-11,12):
    a,b,c=struct.unpack_from('<3i',d,at)
    if a>=0:self.p[base+a]=self.sections[b][0]+c
   for at in range(base+virt,base+exp-11,12):
    a,b,c=struct.unpack_from('<3i',d,at)
    if a>=0:self.types[base+a]=self.s(self.sections[b][0]+c)
 def arr(self,p):return [self.p.get(self.p[p]+i*8) for i in range(self.i(p+8))]
if __name__=='__main__':
 h=HKA('work/crash-motion/Crash.hka')
 print(h.sections);print(list(h.types.items())[:15])
 for at,t in list(h.types.items())[:4]:print(at,t,h.d[at:at+96].hex(),[(k-at,v,h.s(v)[:70] if h.d[v:v+1].isalpha() else '') for k,v in h.p.items() if at<=k<at+96])
