"""Bake owned NST animation tracks into Minecraft skin matrices; assets remain local."""
import json,struct,gzip
from pathlib import Path
import numpy as np
from read_crash_pak import Pak
from inspect_igz import IGZ

ROOT=Path(__file__).resolve().parent
class GLB:
 def __init__(self,path):
  d=Path(path).read_bytes();n=struct.unpack_from('<I',d,12)[0];self.g=json.loads(d[20:20+n]);self.b=d[28+n:]
 def accessor(self,index):
  a=self.g['accessors'][index];v=self.g['bufferViews'][a['bufferView']]
  size={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']]
  dtype={5126:'<f4',5122:'<i2',5123:'<u2',5125:'<u4',5121:'u1'}[a['componentType']]
  result=np.ndarray((a['count'],size),dtype=dtype,buffer=self.b,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',size*np.dtype(dtype).itemsize),np.dtype(dtype).itemsize)).copy()
  if a.get('normalized'):result=np.maximum(-1,result.astype(float)/np.iinfo(dtype).max)
  return result
def trs(t,q,s):
 x,y,z,w=np.array(q)/np.linalg.norm(q)
 m=np.eye(4);m[:3,:3]=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])@np.diag(s);m[:3,3]=t
 return m
def globals_for(nodes,tracks={},time=0):
 local=[]
 for i,n in enumerate(nodes):
  vals={k:np.array(n.get(k,d),dtype=float) for k,d in [('translation',[0,0,0]),('rotation',[0,0,0,1]),('scale',[1,1,1])]}
  for k in vals:
   if (i,k) in tracks:
    ts,vs=tracks[i,k];j=max(0,min(len(ts)-2,np.searchsorted(ts,time)-1));f=np.clip((time-ts[j])/max(1e-8,ts[min(j+1,len(ts)-1)]-ts[j]),0,1)
    a,b=vs[j],vs[min(j+1,len(vs)-1)]
    if k=='rotation' and np.dot(a,b)<0:b=-b
    vals[k]=a*(1-f)+b*f
  local.append(trs(vals['translation'],vals['rotation'],vals['scale']) if 'matrix' not in n else np.array(n['matrix']).reshape(4,4).T)
 parent={c:i for i,n in enumerate(nodes) for c in n.get('children',[])};out={}
 def calc(i):
  if i not in out:out[i]=calc(parent[i])@local[i] if i in parent else local[i]
  return out[i]
 return np.array([calc(i) for i in range(len(nodes))])
if __name__=='__main__':
 import sys
 p=ROOT/'crash-motion/CrashRig.glb';g=GLB(p if p.exists() else ROOT/'crash-motion/Crash.glb');nodes=g.g['nodes'];rest=globals_for(nodes)
 names=json.loads((ROOT/'crash-motion/names.json').read_text());info=json.loads((ROOT/'crash-cache/model.json').read_text())
 print('Nodes',len(nodes),'animations',len(g.g['animations']))
 print([(i,n.get('name'),rest[i][:3,3].tolist()) for i,n in enumerate(nodes) if n.get('name') in ['Bone_Root','Bone_L_Hand','Bone_L_Foot','Bone_Head']])
 print('MC pivots',[(j['name'],j['pivot']) for j in info['joints'] if j['name'] in ['Bone_Root','Bone_L_Hand','Bone_L_Foot','Bone_Head']])
 print('First nodes',nodes[:4]);print('Idle channels',g.g['animations'][455]['channels'][:5])
 lookup={n.get('name'):i for i,n in enumerate(nodes) if n.get('name')}
 pairs=[(j,lookup[j['name']]) for j in info['joints'] if j['name'] in lookup]
 x=np.array([np.r_[rest[i][:3,3],1] for j,i in pairs]);y=np.array([j['pivot'] for j,i in pairs])
 C=np.eye(4);C[:3]=np.linalg.lstsq(x,y,rcond=None)[0].T
 err=np.linalg.norm((C@x.T).T[:,:3]-y,axis=1)
 print('Retarget transform',C.tolist(),'RMS',np.sqrt(np.mean(err**2)),'max',max(err))
 assert max(err)<.005,'Skeleton bind poses differ'
 invC=np.linalg.inv(C);invrest=np.linalg.inv(rest)
 clips={'idle':'idle','walk':'walk','run':'run','jump':'jump','double_jump':'jump_flip','fall':'falling','spin':'attack_spin','land':'land_running','crouch':'idle_cower'}
 clips.update({'slide':'attack_slide','bazooka_idle':'attack_bazooka_middle_center','bazooka_up':'attack_bazooka_top_center','bazooka_down':'attack_bazooka_bottom_center','bazooka_start':'attack_bazooka_start','bazooka_end':'attack_bazooka_end','bazooka_shoot':'attack_bazooka_shoot_partial'})
 clips.update({'bazooka_walk':'walk','bazooka_run':'run','swim_idle':'swim_idle','swim':'swim_forward','swim_spin':'swim_attack_spin'})
 parent={child:i for i,n in enumerate(nodes) for child in n.get('children',[])}
 def under(index,roots):
  while index in parent:
   if nodes[index].get('name') in roots:return True
   index=parent[index]
  return nodes[index].get('name') in roots
 manifest=[]
 with gzip.open(ROOT/'crash-cache/motion.bin.gz','wb') as f:
  f.write(struct.pack('>iii',0x43524D31,len(info['joints']),len(clips)))
  for key,name in clips.items():
   animation=g.g['animations'][names.index(name)];tracks={}
   for ch in animation['channels']:
    sampler=animation['samplers'][ch['sampler']];target=ch['target']['node']+2
    if target>=len(nodes):continue
    # Exporter bakes extracted trajectory into the pelvis translation track.
    # Minecraft moves the whole actor; applying that trajectory to the pelvis
    # alone pulls the legs away from the independently rooted spine.
    if target==lookup['Bone_Pelvis'] and ch['target']['path']=='translation':continue
    tracks[target,ch['target']['path']]=(g.accessor(sampler['input'])[:,0],g.accessor(sampler['output']))
   duration=max(.1,max(ts[-1] for ts,vs in tracks.values()));frames=max(2,int(np.ceil(duration*30))+1)
   if key in ('bazooka_shoot','bazooka_walk','bazooka_run'):
    # Partial tracks include neutral placeholders for unrelated limbs. Keep
    # only arm recoil, or walking legs, and preserve the complete aiming base.
    roots={'Bone_L_Clavicle','Bone_R_Clavicle'} if key=='bazooka_shoot' else {'Bone_Pelvis'}
    overlay={pair:value for pair,value in tracks.items() if under(pair[0],roots)}
    tracks={}
    base=g.g['animations'][names.index('attack_bazooka_middle_center')]
    for ch in base['channels']:
     target=ch['target']['node']+2; path=ch['target']['path']
     if target>=len(nodes) or (target==lookup['Bone_Pelvis'] and path=='translation') or (target,path) in tracks:continue
     sm=base['samplers'][ch['sampler']]; value=g.accessor(sm['output'])[0]
     tracks[target,path]=(np.array([0,duration]),np.array([value,value]))
    tracks.update(overlay)
   f.write(struct.pack('>H',len(key))+key.encode()+struct.pack('>if',frames,duration))
   extrema=[]
   for t in np.linspace(0,duration,frames):
    world=globals_for(nodes,tracks,t);mats=[]
    # HavokToolset exports animation root rotation without the reference
    # skeleton's 180-degree X pre-rotation. Apply it once around its pivot.
    root=lookup['Bone_Root'];pre=np.eye(4);pre[:3,:3]=rest[root][:3,:3];pre[:3,3]=rest[root][:3,3]-pre[:3,:3]@rest[root][:3,3]
    world=pre@world
    for j in info['joints']:
     idx=lookup.get(j['name']);mat=np.eye(4) if idx is None else C@world[idx]@invrest[idx]@invC
     mats.append(mat)
    matrices=np.array(mats);assert np.isfinite(matrices).all()
    f.write(matrices.transpose(0,2,1).astype('>f4').tobytes())
   manifest.append(dict(key=key,source=name,frames=frames,duration=float(duration)))
   print(manifest[-1],flush=True)
 (ROOT/'crash-cache/motion.json').write_text(json.dumps(manifest,indent=2))
