"""Build local-only WumpaCraft assets from the player's owned NST archives."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,struct,subprocess,sys,time,urllib.request,zipfile,traceback,re,uuid
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'work'))
from read_crash_pak import Pak
from inspect_igz import IGZ
from inspect_hka import HKA
from convert_crash import convert,texture
VERSION='wumpacraft-0.3.0-setup2'
def run(script,*args,cwd=None):
 subprocess.run([sys.executable,str(BASE/'work'/script),*map(str,args)],cwd=cwd or BASE,check=True,stdout=sys.stdout,stderr=sys.stderr)
def external(args,cwd):
 subprocess.run(list(map(str,args)),cwd=cwd,check=True,stdin=subprocess.DEVNULL,stdout=sys.stdout,stderr=sys.stderr,timeout=300,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
def download(url,target,sha):
 if target.exists() and hashlib.sha256(target.read_bytes()).hexdigest()==sha:return
 for attempt in range(4):
  try:
   part=target.with_suffix('.partial');urllib.request.urlretrieve(url,part)
   if hashlib.sha256(part.read_bytes()).hexdigest()!=sha:raise RuntimeError('La descarga no coincide con la versión verificada: '+target.name)
   part.replace(target);return
  except Exception:
   if attempt==3:raise
   time.sleep(2**attempt)
def prepare(game,dest):
 os.chdir(BASE);work=BASE/'work';cache=work/'crash-cache';cache.mkdir(exist_ok=True)
 archives=game/'archives' if (game/'archives').is_dir() else game
 assets=json.loads((work/'assets.json').read_text());required=sorted(set(assets.values()))
 missing=[a for a in required if not (archives/a).is_file()]
 if missing:raise RuntimeError('Faltan archivos de tu instalación de Crash N. Sane Trilogy: '+', '.join(missing))
 fingerprint=hashlib.sha256((VERSION+json.dumps([(a,(archives/a).stat().st_size,(archives/a).stat().st_mtime_ns) for a in required])).encode()).hexdigest()
 ready=dest/'wumpacraft-ready.json'
 if ready.exists() and json.loads(ready.read_text()).get('fingerprint')==fingerprint and all((dest/p).is_file() for p in ['model.bin','model.json','motion.bin.gz','props/aku-motion.bin.gz','crashmc-local-audio.zip']):
  print('WumpaCraft ya está preparado.');return
 if shutil.disk_usage(BASE).free<3*1024**3:raise RuntimeError('Se necesitan al menos 3 GB libres para preparar WumpaCraft.')
 locks=json.loads((BASE/'tools.json').read_text());(work/'downloads').mkdir(exist_ok=True);tools=work/'motion-tools';tools.mkdir(exist_ok=True)
 for name in ['havok','vgmstream']:
  folder=tools/name;folder.mkdir(exist_ok=True);entry=locks[name];target=work/'downloads'/(name+('.7z' if name=='havok' else '.zip'))
  print('Preparando herramienta '+name,flush=True);download(entry['url'],target,entry['sha256'])
  if name=='havok':
   import py7zr
   with py7zr.SevenZipFile(target) as z:z.extractall(folder)
  else:
   with zipfile.ZipFile(target) as z:z.extractall(folder)
 original=work/'crash-expansion/originals';audio=work/'crash-expansion/audio';textures=work/'crash-expansion/textures'
 for folder in [original,audio,textures,work/'crash-motion']:folder.mkdir(parents=True,exist_ok=True)
 manifest=[]
 for archive in required:
  print('Leyendo '+archive,flush=True);pak=Pak(archives/archive);lookup={f['path']:f for f in pak.files}
  for path,source in assets.items():
   if source!=archive:continue
   data=pak.extract(lookup[path]);target=original/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);info={'path':path,'source':archive}
   if path.startswith('textures/'):
    png=textures/(hashlib.sha1(path.encode()).hexdigest()[:8]+'_'+Path(path).stem+'.png')
    try:texture(pak,Path(path).stem,png);info['preview']=str(png.relative_to(BASE))
    except KeyError:pass # Normal/specular formats are not used by the diffuse renderer.
   if path.startswith('sound_samples/'):
    pos=data.index(b'FSB5');h=struct.unpack_from('<7I',data,pos);stem=Path(path).name.split(',')[0];fsb=audio/(stem+'.fsb');wav=audio/(stem+'.wav');fsb.write_bytes(data[pos:pos+60+sum(h[3:6])])
    external([tools/'vgmstream/vgmstream-cli.exe','-i','-o',wav,fsb],BASE)
   manifest.append(info)
  del pak
 (work/'crash-expansion/prepared-manifest.json').write_text(json.dumps({'files':manifest}))
 print('Preparando modelo de Crash',flush=True);convert(archives/'Crash.pak',cache)
 run('prepare_props.py')
 havok=tools/'havok';config=havok/'havok_toolset.config'
 shutil.copy2(BASE/'havok_toolset.config',config)
 # Preserve the same default exporter rig layout used by the tested retargeter.
 config.write_text(config.read_text().replace('generation="AUTO"','generation="DEFAULT"'))
 for name,path in [('Crash','anims/Playable/Crash.hka'),('AkuAku','anims/NPC/AkuAku.hka')]:
  actual=next(p for p in assets if p.lower()==path.lower());src=original/actual
  export=work/'crash-motion'/('export-'+uuid.uuid4().hex);export.mkdir();target=export/(name+'.hka');shutil.copy2(src,target)
  config.write_text((BASE/'havok_toolset.config').read_text().replace('scale-type="NONE"','scale-type="INDEPENDENT"') if name=='Crash' else (BASE/'havok_toolset.config').read_text())
  if name=='Crash':
   h=HKA(src);table=next(at for at,t in h.types.items() if t=='hkaSkeleton' and h.s(h.p[at+16])=='animTable');names=[h.s(h.p[h.p[table+40]+i*16]) for i in range(h.i(table+48))];(work/'crash-motion/names.json').write_text(json.dumps(names))
  print('Convirtiendo animaciones de '+name,flush=True);external([havok/'havok_toolset.exe','hk_to_gltf',target],havok)
  glb=target.with_suffix('.glb')
  if not glb.is_file():raise RuntimeError('No se generaron las animaciones de '+name)
  if name=='Crash':shutil.copy2(glb,work/'crash-motion/Crash.glb')
  else:shutil.copy2(glb,havok/'AkuAku.glb')
 run('convert_motion.py');run('bake_aku.py')
 import soundfile as sf,numpy as np
 samples,rate=sf.read(audio/'FX_CRASH_Attack_Spin_03_Loop.wav');samples=samples[:round(.45*rate)].copy();n=min(len(samples),round(.025*rate));samples[-n:]*=np.linspace(1,0,n)[:,None] if samples.ndim>1 else np.linspace(1,0,n)
 with sf.SoundFile(cache/'spin.ogg','w',samplerate=rate,channels=1 if samples.ndim==1 else samples.shape[1],format='OGG',subtype='VORBIS') as dst:
  for start in range(0,len(samples),4096):dst.write(samples[start:start+4096])
 pack=cache/'crashmc-local-audio.zip'
 with zipfile.ZipFile(pack,'w',zipfile.ZIP_DEFLATED) as z:
  z.writestr('pack.mcmeta',json.dumps({'pack':{'pack_format':46,'description':'WumpaCraft: recursos de tu copia local'}}));z.writestr('assets/crashmc/sounds.json',json.dumps({'spin':{'sounds':[{'name':'crashmc:spin'}]}}));z.write(cache/'spin.ogg','assets/crashmc/sounds/spin.ogg')
 run('prepare_expansion_audio.py');run('preview_props.py');run('render_guide.py','idle','.1')
 with zipfile.ZipFile(pack,'a',zipfile.ZIP_DEFLATED) as z:z.write(work/'crash-guide.png','assets/crashmc/textures/gui/crash_guide.png')
 dest.mkdir(parents=True,exist_ok=True)
 # Only the mashup's cache is written, never the source games or saved worlds.
 shutil.copytree(cache,dest,dirs_exist_ok=True)
 (dest/'wumpacraft-ready.tmp').write_text(json.dumps({'version':VERSION,'fingerprint':fingerprint,'ready':True}));(dest/'wumpacraft-ready.tmp').replace(ready)
 print('WumpaCraft listo.',flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--game',type=Path,required=True);p.add_argument('--dest',type=Path,required=True);p.add_argument('--ready',type=Path);a=p.parse_args()
 with (BASE/'prepare.log').open('w',encoding='utf8',buffering=1) as log:
  sys.stdout=sys.stderr=log
  try:
   prepare(a.game.resolve(),a.dest.resolve())
   if a.ready:a.ready.resolve().write_text(json.dumps({'ready':True,'version':VERSION}))
  except Exception:traceback.print_exc();sys.exit(1)

